/*
Ryan Lockman
CSC 160-001
Project: FunctionArgTest
Description: Pass by Value and Pass by Reference arguments of functions.
*/

// Headers
#include <iostream>
#include <string>
#include <ctime>
using namespace std;

// Function Prototypes
int getInput();
void HighLow(int& high, int& low, int a = getInput(), int b = getInput());
void FormatOutput(int high, int low);
void FormatOutput(string name = "RYAN");

int main()
{
	// Declarations
	int num1 = 0, num2 = 0, big = 0, small = 0;

	// Output Header Description Function
	FormatOutput("RRCC");

	// Output FormatOutput Function (before)
	cout << "\nBefore Pass by Reference";
	FormatOutput(big, small);

	// Process HighLow Function
	HighLow(big, small);

	// Output FormatOutput Function (after)
	cout << "\nAfter Pass by Reference";
	FormatOutput(big, small);

    cin.ignore();
	cin.get();
	return 0;
}

void HighLow(int& high, int& low, int a, int b)
{
	// Process High, Low
	if(a > b)
	{
		high = a;
		low = b;
	}
	else if(a < b)
	{
		high = b;
		low = a;
	}
}

void FormatOutput(int high, int low)
{
	// Output Large, Small
	cout << "\nLargest:  " << high << endl;
	cout << "Smallest: "   << low  << endl;
}

void FormatOutput(string name)
{
	// Output Header Description
	cout << "\t********************   \n";
	cout << "\t*   CSC 1601-001   *   \n";
	cout << "\t*\t" << name << "\t   *\n";
	cout << "\t********************   \n";
}

int getInput()
{
	// Declarations
	int num = 0;

	// Input Number
	cout << "\nEnter Number: ";
	cin >> num;

	return(num);
}