/*
 * Source file for the Employee class definition used in CSC160 
 * Written by: Cathy Bishop, Red Rocks Community College, 1999
 * Revised by: Julie Schneider January 2001 to be ANSI compliant
 *
 * NOTE: Comment blocks left out on purpose!
 *
 */

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

#include "employee.h"

// CONSTRUCTORS

Employee::Employee()
{
   name = "Unknown";
   salary = 0.0;
}

Employee::Employee(string nameIn)
{
   name = nameIn;
   salary = 0.0;
}

Employee::Employee(string nameIn, double salaryIn)
{
   name = nameIn;
   salary = salaryIn;
}

// ACCESS FUNCTIONS

string Employee::getName() const
{
   return(name);
}

double Employee::getSalary() const
{
   return(salary);
}
double Employee::getMonthlySalary() const
{
   return(salary/12.0);
}


// SET FUNCTIONS

void Employee::setName(string nameIn)
{
   name = nameIn;
}


void Employee::setSalary(double salaryIn)
{
   salary = salaryIn;
}


// OTHER MEMBER FUNCTIONS

void Employee::print()
{
   cout << fixed << showpoint << setprecision(2);
   cout << name << " makes $" << salary
      << " a year." << endl;
}

// Non-member functions for manipulating Employee objects.

ostream &operator << (ostream &os, const Employee &out_emp)
{
   os << fixed << showpoint << setprecision(2);
   os << out_emp.getName() << " " << out_emp.getSalary() << "\n";

   return(os);
}

istream &operator >> (istream &is, Employee &in_emp)
{
   string name;
   double salary;

   cout << "Enter a first name: ";
   is >> name;
   if (is.eof())
      return(is);

   cout << "Enter an annual salary: ";
   is >> salary;
   if (is.eof())
      return(is);

   in_emp.setName(name);
   in_emp.setSalary(salary);

   return(is);
}