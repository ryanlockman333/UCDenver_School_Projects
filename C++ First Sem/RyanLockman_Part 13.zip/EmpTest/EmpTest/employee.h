/*
 * Header file for the Employee class definition used in CSC160 
 * Written by: Cathy Bishop, Red Rocks Community College, 1999
 * Revised by: Julie Schneider January 2001 to be ANSI compliant
 *
 */

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include <string>

class Employee
{
public:
   // CONSTRUCTOR prototypes

   Employee::Employee();
   Employee::Employee(string nameIn);
   Employee::Employee(string nameIn, double salaryIn);

   // ACCESS function prototypes

   string Employee::getName() const;
   double Employee::getSalary() const;
   double Employee::getMonthlySalary() const;

   // SET FUNCTION prototypes

   void Employee::setName(string nameIn);
   void Employee::setSalary(double salaryIn);

   // OTHER MEMBER FUNCTION prototypes

   void Employee::print();

private:
   string name;
   double salary;

};

// Non-member functions for manipulating Employee objects.

ostream &operator << (ostream &os, const Employee &out_emp);
istream &operator >> (istream &is, Employee &in_emp);

#endif