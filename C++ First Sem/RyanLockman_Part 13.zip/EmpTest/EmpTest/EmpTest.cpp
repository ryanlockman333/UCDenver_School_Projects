/* Ryan Lockman
CSC 160-001
Project: EmpTest
Description: Gets salary and names of employees through a class.
*/

// Headers
#include <iostream>
#include <string>
using namespace std;
#include "Employee.h"

int main()
{
	// Declarations
	string nameIn         = "Sally";
	string nameEmp2;
	double salEmp2        = 55.99;
	double salEmp3        = 0.0;
	double monthlySalEmp3 = 0.0;

	// Classes
	Employee emp1;
	Employee emp2("Julie");
	Employee emp3("Larry", 123.45);
	
	// Process
	nameEmp2       = emp2.getName();
	salEmp3        = emp3.getSalary();
	monthlySalEmp3 = emp3.getMonthlySalary();

	// Set
	emp1.setName  (nameIn);
	emp2.setSalary(salEmp2);

	// Print
	emp1.print();
	emp2.print();
	emp3.print();

	cin.get();
	return 0;
}