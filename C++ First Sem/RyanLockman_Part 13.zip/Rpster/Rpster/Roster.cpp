/*
Ryan Lockman
CSC 160-001
Project: Roster
Description: Stores a list of names in an array as a roster.
*/

// Headers
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// Constants
const int MAX = 50;

// Declared Functions
int  sequentialSearch(string names[], int used, string nameToFind);
void bubbleSort      (string names[], int used);
void selectionSort   (string names[], int used);
int  binarySearch    (string names[], int used, string nameToFind);

int main()
{
	// Declarations
	ifstream inFile;
	string   names[MAX];
	string   tmpName;
	string   nameToFind;
	string   gamePlay   = "N";
	int      indexFound = -1;
	int	     used	    =  0;

	// Open File
	inFile.open("roster.txt");

	// Error Open File
	if(!inFile)
	{
		cout << "Error opening file\n";

		cin.get();
		return -1;
	}

	// Input File
	inFile >> tmpName;

	// Process File
	while(!inFile.fail())
	{
		if(used < MAX)
		{
			names[used] = tmpName;
			used++;
		}
		else
			cout << "Skipped data";

		inFile >> tmpName;
	}

	// Close File
	inFile.close();

	// Print Names Unsorted
	cout << "\nUnsorted List\n";

	for(int i = 0; i < used; i++)
		cout << "\n" << (i+1) << ". " << names[i];

	// Print Names Bubble Sorted
	bubbleSort(names, used);

	cout << "\n\nBubble Sorted List\n";

	for(int i = 0; i < used; i++)
		cout << "\n" << (i+1) << ". " << names[i];

	// Print Names Selection Sorted
	selectionSort(names, used);

	cout << "\n\nSelection Sorted List\n";

	for(int i = 0; i < used; i++)
		cout << "\n" << (i+1) << ". " << names[i];

	// Loop Program
	do
	{
		// Input Name To Find
		cout << "\nEnter a name to find: ";
		cin  >> nameToFind;
	
		// Sequential Search Function
		/*indexFound = sequentialSearch(names, used, nameToFind);*/

		// Binary Search Function
		indexFound = binarySearch(names, used, nameToFind);

		// Process Found
		if(indexFound != -1)
			cout << "\nFound Name: " << names[indexFound] << endl;
		else
			cout << "\nName Not Found\n";

		// Input Again
		cout << "\nDo you want to do it again (Y/N): ";
		cin  >> gamePlay;
		cout << endl;
	}
	while(gamePlay != "N");

	cout << endl << endl;

	cin.get();
	return 0;
}

int sequentialSearch(string names[], int used, string nameToFind)
{
	// Declarations
	int indexFound = -1;

	// Process Sequential Search
	for(int i = 0; i < used; i++)
	{
		if(nameToFind == names[i])
		{
		   indexFound = i;
		   break;
		}
	}

	return(indexFound);
}

void bubbleSort(string names[], int used)
{
	// Declarations
	string tmp;
	bool   sorted = false;

	// Process Bubble Sorted List
	while(!sorted)
	{
		sorted = true;
		for(int i = 0; i < used-1; i++)
		{
			if(names[i] > names[i+1]) // ascending
			{
				tmp        = names[i];
				names[i]   = names[i+1];
				names[i+1] = tmp;
				sorted     = false;
			}
		}
	}
}

void selectionSort(string names[], int used)
{
	// Declarations
	string tmp;
	int    topIndex     = 0;
	int    largestIndex = 0;

	// Process Selection Search
	for(topIndex = 0; topIndex < used; topIndex++)
	{
		largestIndex = topIndex;

		for(int i = topIndex; i < used; i++)
		{
			if(names[i] > names[largestIndex])
				largestIndex = i;
		}

		tmp                 = names[topIndex];
		names[topIndex]     = names[largestIndex];
		names[largestIndex] = tmp;
	}
}

int binarySearch(string names[], int used, string nameToFind)
{
	// Declarations
	bool found      = false;
	int  midIndex   = 0;
	int  firstIndex = 0;
	int  lastIndex  = used-1;

	// Process Binary Search
	while(!found && firstIndex <= lastIndex)
	{
		midIndex = (firstIndex+lastIndex)/2;

		if     (names[midIndex] == nameToFind)
			    found = true;
		else if(names[midIndex]  > nameToFind)
			    firstIndex = midIndex+1;
		else
			    lastIndex = midIndex-1;
	}

	if(found)
		return(midIndex);
	else
		return(-1);
}