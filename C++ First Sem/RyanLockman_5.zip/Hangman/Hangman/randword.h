/*
 Julie Schneider
 randword.h
 Header File
 */

#ifndef RANDWORD_H
#define RANDWORD_H

#include <string>

void   getWords(string fileName);
string getNextWord();

#endif