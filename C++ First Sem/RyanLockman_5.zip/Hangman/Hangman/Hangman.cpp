/*
Ryan Lockman
CSC 160-001
Project: Hangman
Description: Allows a user to play the game hangman.
*/

// Headers
#include <iostream>
#include <cctype>
#include <string>
#include <iomanip>
#include "myFuncts.h"
#include "randword.h"

using namespace std;

// Constant Declarations
const string PHASE1 = "\n -------|    "
		              "\n |      |    "
			          "\n        |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE2 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE3 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n |      |    "
		              "\n        |    "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE4 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|      |    "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE5 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE6 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/       |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE7 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/ \\     |	  "
		              "\n        |	  "
		              "\n      -----\n";
const int MAX = 27;

// Function Prototypes
string mask			   (string str);
string unmask		   (char letter, string str, string masked);
void   drawHangman     (int count);
bool   binarySearch    (char usedLetters[], int used, char letterToFind);
bool   sequentialSearch(char usedLetters[], int used, char letterToFind);
void   bubbleSort      (char usedLetters[], int used);

int main()
{
	// Declarations
	string strWord;
	string strMaskedWord;
	string strToPlay;
	size_t found;
	char   letterToFind;
	char   usedLetters[MAX] = {'\0'};
	bool   indexFound       = false;
	int    used             = 0;
	int    intCounter       = 0;
	int	   intErrorCount    = 0;
	int	   playFlag         = 0;

	// Get Words
	getWords("hangman.dat");

	// Loop To Play
	do
	{
		// Input To Play
		cout << "\n\n\n\n--------------- Hangman Game ---------------\n";
		cout << PHASE7;
		cout << "\nDo you want to play Hangman? (y or n): ";
		cin  >> strToPlay;
		
		// Process playFlag Function
		playFlag = promptYN(strToPlay);
		if(playFlag == PLAY)
		{
			cout << "\nLet's PLAY!\n\n\n\n";

			// Get Word, Mask Word, Reset Everything
			strWord       = strToUpper(getNextWord());
			strMaskedWord = mask(strWord);
			intErrorCount = 0;
			intCounter    = 0;
			used          = 0;

			for(int i = 0; i < used; i++)
				usedLetters[i] = '\0';

			// Process No Words Left
			if(strWord == "")
			{
				cout << "\n\nSorry no words left to Guess."
					 << "\nEdit \"database.dat\" to add more."
					 <<	"\n\nThanks For Playing!" << endl;

				cin.ignore();
				cin.get();
				return 1;
			}

			// Loop Hangman Game
			do
			{
				cout << "\n<<<<<<<<<< MAKE A GUESS >>>>>>>>>>\n";
				drawHangman(intCounter);

				// Output Masked, Bubble Sort and Output usedLetters
				cout << setw(3);
				for(int i = 0; i < strMaskedWord.length(); i++)
					cout << " " << strMaskedWord[i];

				cout << "\n\nGuessed Letters: ";
				bubbleSort(usedLetters, used);
				for(int i = 0; i < used; i++)
					cout << " " << usedLetters[i];

				// Input Letter and Process It
				cout << "\n\nPlease enter a letter to guess: ";
				cin  >> letterToFind;
				cout << "\n\n\n\n";

				letterToFind = chrToUpper(letterToFind);
				indexFound   = binarySearch(usedLetters, used, letterToFind);
				found		 = strWord.find(letterToFind);

				if(found != string::npos)
				{
					if(indexFound == false)
					{
						// Unmask Word, Add Used Letter
						strMaskedWord     = unmask(letterToFind, strWord, strMaskedWord);
						usedLetters[used] = letterToFind;
						used++;

						// Process Win
						if(strMaskedWord == strWord)
						{
							drawHangman(intCounter);

							// Output Masked Word, Won
							cout << setw(3);
							for(int i = 0; i < strMaskedWord.length(); i++)
								cout << " " << strMaskedWord[i];

							cout << "\n\nYou WON!!!\n";
							break;
						}
					}
					else
						cout << "Already guessed: " << letterToFind << endl;
				}
				else if(found == string::npos)
				{
					if(indexFound == false)
					{
						// Add Used Letter, Count Wrong Guess
						usedLetters[used] = letterToFind;
						used++;
						intCounter++;

						cout << letterToFind << " " << "is NOT in the word to guess.\n";

						// Process Wrong Guess
						if(intCounter == 6)
						{
							drawHangman(intCounter);

							// Output Word, Loss
							cout << setw(3);
							for(int i = 0; i < strMaskedWord.length(); i++)
								cout << " " << strMaskedWord[i];

							cout << "\n\nSorry you LOSE - the word was: " << strWord << "\n";
							break;
						}
					}
					else
						cout << "Already guessed: " << letterToFind << endl;
				}
			}
			while(intCounter != 6);
		}
		else if(playFlag == STOP)
		{
			cout << "\nGood Bye!";

			cin.ignore();
			cin.get();
			return 2;
		}
		else if(playFlag == ERROR)
		{
			// Count and Proess Errors
			intErrorCount++;
				
			if(intErrorCount  < 3)
				cout << "\nERROR - please enter (y or n)." << endl;
			else
			{
			    cout << "\nToo Many Errors" << "\n\nGood Bye!";

			    cin.ignore();
				cin.get();
				return 3;
			}
		}
	}
	while(intErrorCount < 3);

	return 0;
}

void drawHangman(int count)
{
	// Process Hangman Design
	if	   (count == 0)
			cout << PHASE1 << endl;
	else if(count == 1)
			cout << PHASE2 << endl;
	else if(count == 2)
			cout << PHASE3 << endl;
	else if(count == 3)
			cout << PHASE4 << endl;
	else if(count == 4)
			cout << PHASE5 << endl;
	else if(count == 5)
			cout << PHASE6 << endl;
	else if(count == 6)
			cout << PHASE7 << endl;
}

bool binarySearch(char usedLetters[], int used, char letterToFind)
{
// Declarations
	bool found      = false;
	int  midIndex   = 0;
	int  firstIndex = 0;
	int  lastIndex  = used - 1;

	// Process Binary Search
	while(!found && firstIndex <= lastIndex)
	{
		midIndex = (firstIndex + lastIndex) / 2;

		if     (usedLetters[midIndex] == letterToFind)
			    found = true;
		else if(usedLetters[midIndex]  < letterToFind)
			    firstIndex = midIndex + 1;
		else
			    lastIndex  = midIndex - 1;
	}

	if(found)
		return(true);
	else
		return(false);
}

void bubbleSort(char usedLetters[], int used)
{
	// Declarations
	char tmp;
	bool sorted = false;

	// Process Bubble Sort Ascending List
	while(!sorted)
	{
		sorted = true;
		for(int i = 0; i < used - 1; i++)
		{
			if(usedLetters[i] > usedLetters[i + 1])
			{
				tmp                = usedLetters[i];
				usedLetters[i]     = usedLetters[i + 1];
				usedLetters[i + 1] = tmp;
				sorted             = false;
			}
		}
	}
}

string mask(string str)
{
     for(int i = 0; i < str.length(); i++)
     {
		if(isprint(str[i]))
			str[i] = '_';
		else
			continue;
     }
     
     return(str);
}

string unmask(char letter, string str, string masked)
{
     for(int i = 0; i < str.length(); i++)
	 {   
		if(str[i] == letter)
			masked[i] = letter;   
     }
            
     return(masked);
 }