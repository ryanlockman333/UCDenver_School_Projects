/*
Ryan Lockman
CSC 160-001
Project: PinPassword
Description: Using string to secure the code.
*/

// Headers
#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int main()
{
	// Declarations
	string       pin;
	string		 strAmt;
	unsigned int amt = 0.0;

	// Input Pin
	cout << "Enter pin: ";
	getline(cin, pin, '\n');

	// Process Pin
	while (pin.length() != 5)
	{
		cout << "Enter pin: ";
		getline(cin, pin, '\n');
	}

	if (pin == "12345")
	{
		cout << "Enter amt: ";
		cin  >> strAmt;

		if (strAmt.length() > 10)
			cout << "\nOverflow Error\n\a\a";
		else
			amt = atoi(strAmt.c_str());
	}

	// Output PIN, AMT
	cout << "\nValues entered\n";
	cout << "PIN: " << pin << endl;
	cout << "AMT: " << amt << endl;
	cout << endl    << endl;

	cin.ignore();
	cin.get();
	return 0;
}