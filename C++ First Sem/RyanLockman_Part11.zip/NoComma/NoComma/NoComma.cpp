/*
Ryan Lockman
CSC 160-001
Project: NoComma
Description: Given # remove comma.
*/

// Headers
#include <string>
#include <iostream>

using namespace std;

int main()
{
	// Declarations
	string commaNum; // default constructor
	string beforeComma = "";
	string afterComma("");
	int len		   = 0;
	int commaIndex = 0;

	// Input Number
	cout << "Enter a #: ";
	cin  >> commaNum;

	// Process Commas
	len        = commaNum.length();
	commaIndex = commaNum.find(',');

	while(commaIndex != string::npos)
	{
		commaNum   = commaNum.erase(commaIndex, 1);
		commaIndex = commaNum.find(',');
	}

	//beforeComma = commaNum.substr(0, len-4);
	//afterComma  = commaNum.substr(len-3, 3);
	//commaNum    = beforeComma + afterComma;

	// Output Comma Num
	cout << "\nComma Num Before: "
		 << commaNum;
	cout << endl << endl;

	system("pause");
	return 0;
}