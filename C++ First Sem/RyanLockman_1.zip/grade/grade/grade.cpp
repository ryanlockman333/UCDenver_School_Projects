/*
Ryan Lockman
CSC 160-001
Project: grade
Description: This program calculates the exam, project, and participation grade average.
*/

// Headers
#include <iostream>
using namespace std;

int main()
{
	// Local Declarations
	float  fltExam       = 0;
	float  fltExamAvg    = 0;
	float  fltProject    = 0;
	float  fltProjectAvg = 0;
	float  fltPart       = 0;
	float  fltPartAvg    = 0;
	float  fltTotalAvg   = 0;
	char   chrFinalGrade;

	// Input
	cout << "Please enter EXAM average:          ";
	cin  >> fltExam;

	cout << "\nPlease enter PROJECT average:       ";
	cin  >> fltProject;

	cout << "\nPlease enter PARTICIPATION average: ";
	cin  >> fltPart;

	// Process
	fltExamAvg    = fltExam * .3;
	fltProjectAvg = fltProject * .6;
	fltPartAvg    = fltPart * .1;
	fltTotalAvg   = (fltExamAvg + fltProjectAvg + fltPartAvg);

	if		(fltTotalAvg >= 90)
			chrFinalGrade = 'A';
	else if ((fltTotalAvg >= 80) && (fltTotalAvg <= 89))
			chrFinalGrade = 'B';
	else if ((fltTotalAvg >= 70) && (fltTotalAvg <= 79))
			chrFinalGrade = 'C';
	else if ((fltTotalAvg >= 60) && (fltTotalAvg <= 69))
			chrFinalGrade = 'D';
	else if (fltTotalAvg <= 59)
			chrFinalGrade = 'F';

	// Output
	cout << "\n\n\n Total average: " << fltTotalAvg;
	cout << "\n Final grade:   "     << chrFinalGrade;

	/* 
	Test Plan
	case1: exam 98, project 100, participation 92
			 total average: 98.6, grade A
	case2: exam 88, project 90,  participation 78
			 total average: 88.2, grade B
	case3: exam 50, project 79,  participation 76
			 total average: 70,   grade C
	case4: exam 48, project 72,  participation 81
			 total average: 65.7, grade D
	case5: exam 48, project 65,  participation 54
			 total average: 58.8, grade F
	*/

	cin.get();
	cin.get();
	return 0;
}