/*
Ryan Lockman
CSC 160-001
Project: chpt2
Description: The following program displays your first/last name and also todays temperature.
*/

// Headers
#include <iostream>
#include <string>
using namespace std;

int main()
{
	// Local Declarations
	string stgFirst;
	string stgLast;
	int    intTemp = 0;

	// Input
	cout << "Enter FIRST name: ";
	cin  >> stgFirst;
	cout << endl;

	cout << "Enter LAST name:  ";
	cin  >> stgLast;
	cout << endl;

	cout << "Enter today's TEMPERATURE: ";
	cin  >> intTemp;
	cout << endl << endl;

	// Output
	cout << stgFirst << " " << stgLast << " "
		 << "today's temperature is: " << intTemp;

	cin.get();
	cin.get();
	return 0;
}