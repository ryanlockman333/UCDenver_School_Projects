/*
Ryan Lockman
CSC 160-001
Project: hangman
Description: Allows a user to play the game hangman.
*/

// Headers
#include <iostream>
using namespace std;

int main()
{
	// Output
	cout << "     -------|   " << endl
		 <<	"     |	    |    " << endl
		 <<	" 	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	  -----      " << endl;


	cout << "\n     -------| " << endl
		 <<	"     |	    |    " << endl
		 <<	"     0      |   " << endl
		 <<	"	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	  -----      " << endl;


	cout << "\n     -------| " << endl
		 <<	"     |	    |    " << endl
		 <<	"     0      |   " << endl
		 <<	"     |      |   " << endl
		 <<	"	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	  -----      " << endl;


	cout << "\n     -------| " << endl
		 <<	"     |	    |    " << endl
		 <<	"     0      |   " << endl
		 <<	"    -|      |   " << endl
		 <<	"	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	  -----      " << endl;

	cout << "\n     -------| " << endl
		 <<	"     |	    |    " << endl
		 <<	"     0      |   " << endl
		 <<	"    -|-     |   " << endl
		 <<	"	    |        " << endl
		 <<	"	    |        " << endl
		 <<	"	  -----      " << endl;

	cout << "\n     -------| " << endl
		 <<	"     |	    |    " << endl
		 <<	"     0      |   " << endl
		 <<	"    -|-     |   " << endl
		 <<	"    /       |   " << endl
		 <<	"	    |        " << endl
		 <<	"	  -----      " << endl;

	cout << "\n     -------| " << endl
		 <<	"     |	    |    " << endl
		 <<	"     0      |   " << endl
		 <<	"    -|-     |   " << endl
		 <<	"    / \\     |  " << endl
		 <<	"	    |        " << endl
		 <<	"	  -----      " << endl;

	cin.get();
	return 0;
}