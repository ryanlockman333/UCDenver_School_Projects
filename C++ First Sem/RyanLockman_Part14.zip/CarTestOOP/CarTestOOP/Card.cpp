/*
Ryan Lockman
CSC 160-001
Card class defenition file.
*/

// Headers
#include <iostream>
#include <sstream>
using namespace std;
#include "Card.h"

// Constructors
Card::Card() // default constructor
{
	setRank(2);
	setSuit(1);
}

Card::Card(int rankIn, int suitIn)
{
	setRank(rankIn);
	setSuit(suitIn);
}

// Set Member Functions
void Card::setRank(int rankIn)
{
	if(rankIn >= 2 && rankIn <= 14)
		rank = rankIn;
	else
		rank = 2;
}

void Card::setSuit(int suitIn)
{
	if(suitIn >= 1 && suitIn <= 4)
		suit = suitIn;
	else
		suit = 1;
}

// Get Member Functions
int Card::getRank() const
{
	return(rank);
}

int Card::getSuit() const
{
	return(suit);
}

// Other Member Functions
string Card::FormatCard()
{
	string card = FormatRankStr() + " of " + FormatSuitStr();
	return(card);
}

string Card::FormatRankStr()
{
	string strRank;
	
	// Process rank1 High Cards
	switch (rank)
	{
	case 11:
		strRank = "Jack";
		break;
	case 12:
		strRank = "Queen";
		break;
	case 13:
		strRank = "King";
		break;
	case 14: case 1:
		strRank = "Ace";
		break;
	default:
		stringstream ss;
		ss << rank;
		ss >> strRank;
	}
	
	return(strRank);
}

string Card::FormatSuitStr()
{
	string strSuit;

	// Process suit1 Suit
	switch (suit)
	{
	case 1:
		strSuit = "Clubs";
		break;
	case 2:
		strSuit = "Diamonds";
		break;
	case 3:
		strSuit = "Hearts";
		break;
	case 4:
		strSuit = "Spades";
		break;
	default:
		strSuit = "ERROR SUITE";
	}

	return(strSuit);
}

void Card::PrintCard()
{
	cout << FormatCard() << endl;
}