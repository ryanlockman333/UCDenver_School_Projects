/*
Ryan Lockman
CSC 160-001
Project: CarTestOOP
Description: Using Card class create Card object.
*/

// Headers
#include <iostream>
#include "Card.h"

int main()
{
	// Delcare Classes
	Card myCard;
	Card yourCard;

	// Set Classes
	myCard.setRank(4);
	myCard.setSuit(3);
	yourCard.setRank(13);
	yourCard.setSuit(2);

	// Print Classes
	myCard.PrintCard();
	yourCard.PrintCard();

	system("pause");
	return 0;
}