/*
Ryan Lockman
CSC 160-001
Card class declaration file.
*/

#ifndef CARD_H
#define CARD_H

// Headers
#include <string>
using namespace std;

class Card
{
public:
	// Constructors
	Card::Card(); // default constructor
	Card::Card(int rankIn, int suitIn);

	// Set Member Functions
	void Card::setRank(int rankIn);
	void Card::setSuit(int suitIn);

	// Get Member Functions
	int Card::getRank() const;
	int Card::getSuit() const;

	// Other Member Functions
	string Card::FormatCard   ();
	string Card::FormatRankStr();
	string Card::FormatSuitStr();
	void   Card::PrintCard    ();

private:
	// Data Members
	int rank;
	int suit;
};

#endif