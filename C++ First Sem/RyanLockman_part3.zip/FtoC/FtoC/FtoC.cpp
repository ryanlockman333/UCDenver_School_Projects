/*
Ryan Lockman
CSC 160-001
Project: FtoC
Description: Given fahrenheit, calculate celsius.
*/

// Headers
#include <iostream>
using namespace std;

int main()
{
	// Local Declarations - fahrenheit, celcius
	double fahrenheit = 0.0, celsius = 0.0;

	// Input - fahrenheit
	cout << "Please enter fahrenheit: ";
	cin  >> fahrenheit;

	// Process - celsius = (fahrenheit -32)*5/9
	celsius = (fahrenheit - 32) * 5.0 / 9;

	// Output - celsius
	cout << "\n\nYour celcius: " << celsius;

	// Test Plan F: 32 C: 0, F: 212 C :100

	cin.get();
	cin.get();
	return 0;
}