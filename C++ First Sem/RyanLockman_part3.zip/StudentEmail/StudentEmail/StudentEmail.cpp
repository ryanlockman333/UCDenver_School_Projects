/*
Ryan Lockman
CSC 160-001
Project: StudentEmail
Description: Basic string class manipulation to generate student email.
*/

// Headers
#include <iostream> // ostream, istream
#include <string>   // string data type
using namespace std;

int main()
{
	// Local Declarations - first, middle, last, email
	string stgFirst = "";
	string stgMiddle;
	string stgLast;
	string stgEmail;

	// Input - first, middle, last
	cout << "Enter first name:  ";
	cin  >> stgFirst;

	cout << "\nEnter middle name: ";
	cin  >> stgMiddle;

	cout << "\nEnter last name:   ";
	cin  >> stgLast;

	// Process - generate student email
	stgEmail = stgFirst + stgMiddle + stgLast +
			   "@student.cccs.edu";

	// Output - student email
	cout << "\n\nEmail: " << stgEmail;

	cin.get();
	cin.get();
	return 0;
}
