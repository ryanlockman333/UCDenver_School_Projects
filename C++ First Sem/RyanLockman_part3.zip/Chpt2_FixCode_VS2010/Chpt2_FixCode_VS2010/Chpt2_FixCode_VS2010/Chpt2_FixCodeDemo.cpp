/*
Ryan Lockman
CSC 160-001
Project 2: Chpt2_FixCodeDemo
Description: Fix the code.
*/

// Headers
#include <iostream>
using namespace std;

// Declarations
const int DOLLAR_VALUE  = 100;
const int QUARTER_VALUE = 25;
const int DIME_VALUE    = 10;
const int NICKLE_VALUE  = 5;

int main()
{
	// Local Declarations
	int totalPennies = 0, leftPennies = 0;
	int dollars = 0, quarters = 0, dimes = 0, nickels = 0, pennies = 0;

	// Input
	cout << "Enter total number of pennies:  ";
	cin  >> totalPennies;

	// Process
	dollars	    = totalPennies / DOLLAR_VALUE;

	leftPennies = totalPennies;
	leftPennies = totalPennies % 100;

	quarters	= leftPennies / QUARTER_VALUE;
	leftPennies = leftPennies % 25;

	dimes		= leftPennies / DIME_VALUE;
	leftPennies = leftPennies % 10;

	nickels		= leftPennies / NICKLE_VALUE;
	leftPennies = leftPennies % 5;

	pennies     = leftPennies;

	// Output
	cout << "\n\nDollars:   " << dollars  << endl;
	cout << "\nQuarters:  "   << quarters << endl;
	cout << "\nDimes:     "   << dimes    << endl;
	cout << "\nNickels:   "   << nickels  << endl;
	cout << "\nPennies:   "   << pennies  << endl;

	/* 
	Test Plan
	TotalPennies: 537
	Dollars:      5
    Quarters:     1
	Dimes:        1
	Nickles:      0
	Pennies:      2
	*/

	cin.get();
	cin.get();
	return 0;
}