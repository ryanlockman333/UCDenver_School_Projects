/*
Ryan Lockman
MyFuncts.cpp
Stand-alone function definitions.
*/

#include <cctype>
using namespace std;
#include "myFuncts.h"

string strToUpper(string str)
{
	string ans = str;

	for(int i = 0; i < str.length(); i++)
		ans[i] = toupper(str[i]);

	return(ans);
}
string strToLower(string str)
{
	string ans = str;

	for(int i = 0; i < str.length(); i++)
		ans[i] = tolower(str[i]);

	return(ans);

}