/*
Ryan Lockman
CSC 160-001
Project: FunctionTest
Description: Writing a stand alone function.
*/

// Headers
#include <iostream>
#include <cmath>
#include <string>
using namespace std;
#include "myFuncts.h"

// Function Prototype
double myPow(int baseNum, int powerNum);

int main()
{
	// Local Declarations
	string name, upper, lower;
	int    base   = 0, power = 0;
	double answer = 0.0;

	// Input Name
	cout << "Enter your name: ";
	cin  >> name;

	// Process Name
	upper = strToUpper(name);
	lower = strToLower(name);

	// Output Name
	cout << "\nName:  " << name  << endl;
	cout << "\nUpper: " << upper << endl;
	cout << "\nLower: " << lower << endl << endl;

	// Input Base/Power
	cout << "Enter base num:  ";
	cin  >> base;
	cout << "Enter power num: ";
	cin  >> power;

	// Process Answer
	answer = myPow(base, power);

	// Output Answer
	cout << "\nAnswer: " << answer;
	cout << endl << endl;

	cin.ignore();
	cin.get();
	return 0;
}

// function header + implementation
// definition of function
double myPow(int baseNum, int powerNum)
{
	// Local Declarations
	double ans = 1.0;

	// Process ans
	for(int i = 0; i < powerNum; i++)
		ans *= baseNum;

	return(ans);
}