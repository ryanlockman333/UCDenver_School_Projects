/*
Ryan Lockman
MyFuncts.h
Stand alone function declarations.
*/

#ifndef  MYFUNCTS_H
#define  MYFUNCTS_H
#include <string>
using namespace std;

string strToUpper(string str);
string strToLower(string str);

#endif