/*
Ryan Lockman
CSC 160-001
Project 2: Chpt2_FixCodeDemo
Description: Fix the code.
*/

// Headers
#include <iostream>
using namespace std;

// Constant Declarations
const int DOLLAR_VALUE  = 100;
const int QUARTER_VALUE = 25;
const int DIME_VALUE    = 10;
const int NICKLE_VALUE  = 5;

int main()
{
	// Local Declarations
	int  days = 0;
	bool calcPay = false;
	int  totalPennies = 1, leftPennies = 0;
	int  dollars = 0, quarters = 0, dimes = 0, nickels = 0, pennies = 0;

	while(!calcPay)
	{
		cout << "\nEnter total days (-1 to quit): ";
		cin  >> days;
		if(days == -1)
			calcPay = true;
		else if(days < 0)
		{
			cout << "\nDays must be positive!\n";
		continue;
		}
		else
		{
			//TODO: calc total Pennies for given days
			totalPennies = 1;
			for(int i = 2; i <= days; i++)
				totalPennies *= 2;

			// Process
			dollars	     = totalPennies / DOLLAR_VALUE;
			leftPennies  = totalPennies;
			leftPennies -= (dollars * DOLLAR_VALUE);

			// Output
			cout << "\n$" << dollars << "." << totalPennies << endl;

			if(totalPennies < 10)
				cout << "0";

			cout << totalPennies << endl;
			}
	}

	/* 
	Test Plan
	Days 2, $0.2, 02
	*/

	cin.get();
	return 0;
}