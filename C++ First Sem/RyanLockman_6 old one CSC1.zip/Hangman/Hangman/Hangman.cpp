/*
Ryan Lockman
CSC 160-001
Project: Hangman
Description: Allows a user to play the game hangman.
*/

// Headers
#include <iostream>
#include <iomanip>
#include "myFuncts.h"
#include "randword.h"
#include "scoreKeeper.h"

// Constant Declarations
const string PHASE1 = "\n -------|    "
		              "\n |      |    "
			          "\n        |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE2 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE3 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n |      |    "
		              "\n        |    "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE4 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|      |    "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE5 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE6 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/       |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE7 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/ \\     |	  "
		              "\n        |	  "
		              "\n      -----\n";
const int MAX = 27;

// Function Prototypes
void drawHangman (int count);

int main()
{
	// Declarations
	ScoreKeeper players[5];
	string		strWord;
	string		strMaskedWord;
	string		strToPlay;
	string		strToKeep;
	string		nameIn;
	size_t		found;
	char		letterToFind;
	char		usedLetters[MAX] = {'\0'};
	bool		indexFound       = false;
    int			playerNumber     = 0;
	int			scoreIn			 = 0;
	int			used             = 0;
	int			usedPlayers      = 0;
	int			intCounter       = 0;
	int			intErrorCount    = 0;
	int			playFlag         = 0;
	int			keepFlag         = 0;

	// Get Words
	getWords("hangman.dat");

	// Loop To Play
	do
	{
		// Input To Play
		cout << "\n\n\n\n--------------- Hangman Game ---------------\n";
		cout << PHASE7;
		cout << "\nDo you want to play Hangman? (Y/N): ";
		cin  >> strToPlay;
		
		// Process playFlag Function
		playFlag = promptYN(strToPlay);
		if(playFlag == PLAY)
		{
			// Get Word, Mask Word, Reset Everything
			strWord       = strToUpper(getNextWord());
			strMaskedWord = mask(strWord);
			intErrorCount = 0;
			intCounter    = 0;
			used          = 0;
			for(int i = 0; i < used; i++)
				usedLetters[i] = '\0';

			// Process No Words Left
			if(strWord == "")
			{
				cout << "\n\nSorry no words left to guess."
					 << "\nEdit \"database.dat\" to add more."
					 <<	"\n\nThanks For Playing!" << endl;

				cin.ignore();
				cin.get();
				return 1;
			}

			cout << "\nLet's PLAY!";
			cout << "\n\nStart new game? (Y/N): ";
			cin  >> strToKeep;

			// Process Keep Players
			keepFlag = promptYN(strToKeep);
			if(keepFlag == PLAY)
			{
				cout << "\n\nHow many players? (1 - 5): ";
				cin  >>  playerNumber;

				for(int i = 0; i < playerNumber; i++)
				{
					cout << "\nPlease enter your name:  ";
					cin  >> nameIn;
					players[i].setName(nameIn);
					players[i].setScore(scoreIn);
					players[i].formatPlayerInfo();
				}
			}
			else if(keepFlag == STOP)
			{
				for(int i = 0; i < playerNumber; i++)
				{
					players[i].getScore();
					players[i].getName();
				}
			}
			else if(keepFlag == ERROR)
			{
				cout << "\nERROR - Didn't enter (Y/N).\n"
					 << "        Starting new game.\n";

				cout << "\n\nHow many players? (1 - 5): ";
				cin  >>  playerNumber;

				for(int i = 0; i < playerNumber; i++)
				{
					cout << "\nPlease enter your name:  ";
					cin  >> nameIn;
					players[i].setName(nameIn);
					players[i].setScore(scoreIn);
					players[i].formatPlayerInfo();
				}
			}

			cout << "\n>>>>>>>>>>>> SCORE CARD <<<<<<<<<<<<\n";
			for(unsigned int i = 0; i < playerNumber; i++)
				players[i].printScoreKeeperInfo();

			// Loop Hangman Game
			do
			{
				cout << "\n <<<<<<<<<< MAKE A GUESS >>>>>>>>>>\n";
				drawHangman(intCounter);

				// Output Masked, Bubble Sort and Output usedLetters
				cout << setw(3);
				for(unsigned int i = 0; i < strMaskedWord.length(); i++)
					cout << " " << strMaskedWord[i];

				cout << "\n\nGuessed Letters: ";
				bubbleSort(usedLetters, used);
				for(int i = 0; i < used; i++)
					cout << " " << usedLetters[i];

				// Input Letter and Process It
				cout << "\n\nPlease enter a letter to guess: ";
				cin  >> letterToFind;
				cout << "\n\n\n\n";

				letterToFind = chrToUpper(letterToFind);
				indexFound   = binarySearch(usedLetters, used, letterToFind);
				found		 = strWord.find(letterToFind);

				if(found != string::npos)
				{
					if(indexFound == false)
					{
						// Unmask Word, Add Used Letter
						strMaskedWord     = unmask(letterToFind, strWord, strMaskedWord);
						usedLetters[used] = letterToFind;
						used++;

						// Process Win
						if(strMaskedWord == strWord)
						{
							drawHangman(intCounter);

							// Output Masked Word, Won
							cout << setw(3);
							for(unsigned int i = 0; i < strMaskedWord.length(); i++)
								cout << " " << strMaskedWord[i];

							scoreIn++;

							cout << "\n\nYou WON!!!\n";
							break;
						}
					}
					else
						cout << "Already guessed: " << letterToFind << endl;
				}
				else if(found == string::npos)
				{
					if(indexFound == false)
					{
						// Add Used Letter, Count Wrong Guess
						usedLetters[used] = letterToFind;
						used++;
						intCounter++;
						cout << letterToFind << " " << "is NOT in the word to guess.\n";

						// Process Wrong Guess
						if(intCounter == 6)
						{
							// Output Word, Loss
							drawHangman(intCounter);
							cout << setw(3);
							for(unsigned int i = 0; i < strMaskedWord.length(); i++)
								cout << " " << strMaskedWord[i];

							cout << "\n\nSorry you LOSE - the word was: " << strWord << "\n";
							break;
						}
					}
					else
						cout << "Already guessed: " << letterToFind << endl;
				}
			}
			while(intCounter != 6);
		}
		else if(playFlag == STOP)
		{
			cout << "\nGood Bye!";

			cin.ignore();
			cin.get();
			return 2;
		}
		else if(playFlag == ERROR)
		{
			// Count and Proess Errors
			intErrorCount++;
				
			if(intErrorCount  < 3)
				cout << "\nERROR - please enter (Y/N)." << endl;
			else
			{
			    cout << "\nToo Many Errors" << "\n\nGood Bye!";

			    cin.ignore();
				cin.get();
				return 3;
			}
		}
	}
	while(intErrorCount < 3);

	return 0;
}

void drawHangman(int count)
{
	// Process Hangman Design
	if	   (count == 0)
			cout << PHASE1 << endl;
	else if(count == 1)
			cout << PHASE2 << endl;
	else if(count == 2)
			cout << PHASE3 << endl;
	else if(count == 3)
			cout << PHASE4 << endl;
	else if(count == 4)
			cout << PHASE5 << endl;
	else if(count == 5)
			cout << PHASE6 << endl;
	else if(count == 6)
			cout << PHASE7 << endl;
}