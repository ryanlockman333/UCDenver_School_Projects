/*
Ryan Lockman
player.cpp
Stand-alone class defenitions.
*/

// Headers
#include <iostream>
#include <iomanip>
#include <sstream>
#include "player.h"

// Constructors
Player::Player() // Default
{
	intScore = 0;
	strName  = "Unknown";
}

Player::Player(int scoreIn)
{
	intScore = scoreIn;
	strName  = "Unknown";
}
Player::Player(string nameIn)
{
	intScore = 0;
	strName  = nameIn;
}

Player::Player(int scoreIn, string nameIn)
{
	intScore = scoreIn;
	strName  = nameIn;
}

// Set Member Functions
void Player::setScore(int scoreIn)
{
	intScore = scoreIn;
}

void Player::setName(string nameIn)
{
	strName = nameIn;
}

// Get Member Functions
int Player::getScore() const
{
	return(intScore);
}

string Player::getName() const
{
	return(strName);
}

// Other Member Functions
void Player::formatPlayerInfo()
{
	stringstream ss;
	ss.str(strName);
	ss << "Player: " << strName << "\t\tScore: " << intScore;
	strName = ss.str();
}

void Player::printPlayerInfo()
{
	cout << setw(12);
	cout << strName << endl;
}