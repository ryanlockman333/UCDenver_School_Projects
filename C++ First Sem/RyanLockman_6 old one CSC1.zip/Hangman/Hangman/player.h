/*
Ryan Lockman
player.h
Stand-alone class declarations.
*/

#ifndef PLAYER_H
#define PLAYER_H

// Headers
#include <string>
using namespace std;

// Classes
class Player
{
public:
	// Constructors
	Player::Player(); // Default
	Player::Player(int scoreIn);
	Player::Player(string nameIn);
	Player::Player(int scoreIn, string nameIn);

	// Set Member Functions
	void Player::setScore(int scoreIn);
	void Player::setName (string nameIn);	

	// Get Member Functions
	int    Player::getScore() const;
	string Player::getName () const;

	// Other Member Functions
	void Player::formatPlayerInfo();
	void Player::printPlayerInfo ();

private:
	// Data Members
	int    intScore;
	string strName;
};

#endif