/*
Ryan Lockman
scoreKeeper.h
Stand-alone class declarations.
*/

#ifndef SCOREKEEPER_H
#define SCOREKEEPER_H

// Headers
#include "player.h"

// Constants
const int MAX_PLAYERS = 5;

// Classes
class ScoreKeeper: public Player
{
public:
	//Constructor
	ScoreKeeper::ScoreKeeper(); // Default

	// Get Member Functions
	int ScoreKeeper::getPlayer() const;
	int ScoreKeeper::getUsed  () const;

	// Other Member Functions
	void ScoreKeeper::addPlayer           (Player& playerToAdd);
	void ScoreKeeper::removePlayer        (Player  playerToRemove);
	void ScoreKeeper::incrementPlayerScore(Player& playerObj);
	void ScoreKeeper::printScoreKeeperInfo();

private:
	// Data Members
	Player players[MAX_PLAYERS];
	int    intUsed;
};

#endif