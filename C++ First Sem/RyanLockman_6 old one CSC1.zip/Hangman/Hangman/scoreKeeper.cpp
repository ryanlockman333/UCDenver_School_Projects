/*
Ryan Lockman
scoreKeeper.cpp
Stand-alone class defenitions.
*/

// Headers
#include <iostream>
#include "scoreKeeper.h"
#include "myFuncts.h"

//Constructor
ScoreKeeper::ScoreKeeper() // Default
{
	intUsed = 0;
}

// Get Member Functions
int ScoreKeeper::getPlayer() const
{
	return 0;
}

int ScoreKeeper::getUsed() const
{
	return(intUsed);
}

// Other Member Functions
void ScoreKeeper::addPlayer(Player& playerToAdd)
{
	for(int i = 0; i <= intUsed; i++)
	{
		players[i] = playerToAdd;
		intUsed++;
	}
}

void ScoreKeeper::removePlayer(Player playerToRemove)
{
	for(unsigned int i = 0; i < MAX_PLAYERS; i++)
	{
		
	}
}

void ScoreKeeper::incrementPlayerScore(Player& playerObj)
{
	int score;
	playerObj.setScore(score++);
}

void ScoreKeeper::printScoreKeeperInfo()
{
	printPlayerInfo();
}