/*
Ryan Lockman
CSC 160-001
Project: Numbers_Loops
Description: Find averages using while loop.
*/

// Headers
#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	// Local Declarations
	ifstream inFile;
	int      num = 0, sum = 0, count = 0;
	double   average = 0.0;
	bool     flag = false;

	// Open inFile
	inFile.open("numbers.dat");

	// Error inFile
	if(!inFile)
	{
		cout << "Error opening file\n";

		system("pause");
		return 1;
	}
	
	// Input inFile
	inFile >> num;

	while(!inFile.fail())
	{
		cout << "Data: " << num << endl;
		if(num >= 0)
		{
			count++;
			sum += num;
		}

		inFile >> num;
	}

	// Process
	/*do
	{
		cout << "Enter a number (-1 to quit): ";
		cin  >> num;

		if (num == -1)
			break;
		else if (num < 0)
		{
			cout << "Number must be positive - Re-Enter.\n";
			continue;
		}
		else
		{
			count++;
			sum += num;
		}
	} while(num != -1);*/

	if (count > 0)
	{
		average = sum * 1.0 / count;
		cout << "\nAverage: " << average;
	}
	else
		cout << "No data to calculate average.";

	cout << endl << endl;

	system("pause");
	return 0;
}