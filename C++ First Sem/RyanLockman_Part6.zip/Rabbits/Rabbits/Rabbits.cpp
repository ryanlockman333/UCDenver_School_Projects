/*
Ryan Lockman
CSC 160-001
Project: Rabbits
Description: rabbit population
			 given months
			 using for loops
*/

// Headers
#include <iostream>

using namespace std;

int main()
{
	// Local Declarations
	int totalRabbits = 2;
	int totalMonths  = 0;

	// Input
	cout << "Enter total months: ";
	cin  >> totalMonths;

	// Process
	for(int i = 4; i <= totalMonths; i += 4)
		totalRabbits *= 5;

	// Output
	cout << "\nTotal Rabbits: " << totalRabbits << "\n\n";

	cin.ignore();
	cin.get();
	return 0;
}