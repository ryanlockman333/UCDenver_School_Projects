/*
Ryan Lockman
CSC 160-001
Project: Craps
Description: Using functions, play the game of craps.
*/

// Headers
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

#include "myFuncts.h"

// Function Prototypes
int rollDie(); // six sided die
int comeOutRoll(int die1, int die2);

int main()
{
	// Declarations
	int    playFlag = PLAY;
	string response;
	int    die1 = 0, die2 = 0;
	int	   comeOutValue = 0;

	srand(time(NULL));

	// Process STOP
	while(playFlag != STOP)
	{
		// Input Response
		cout << "\nDo you want to play craps? ";
		cin  >> response;

		// Process Response
		playFlag = promptYN(response);

		if(playFlag == PLAY)
		{
			// Process rollDie
			die1 = rollDie();
			die2 = rollDie();

			// Output Die
			cout << "\nDie 1: " << die1 << endl;
			cout << "Die 2: "   << die2 << endl;

			// Process comeOutValue
			comeOutValue = comeOutRoll(die1, die2);
			
			if(comeOutValue == STOP)
				cout << "\nYOU LOSE" << endl;
			else if(comeOutValue == PLAY)
				cout << "\nYou WIN"  << endl;
			else
				cout << "\nGet the Point - still under construction";
		}
	}

	return 0;
}

int rollDie() // six sided die
{
	return(rand() % 6 + 1);	
}

int comeOutRoll(int die1, int die2)
{
	// Declarations
	int ans = 0;
	int sum = die1 + die2;

	// Process Sum
	if(sum == 2 || sum == 3 || sum == 12)
		ans = STOP;
	else if(sum = 7 || sum == 11)
		ans = PLAY;
	else
		ans = sum;

	return(ans);
}