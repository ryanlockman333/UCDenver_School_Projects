/*
Ryan Lockman
MyFuncts.h
Stand alone function declarations.
*/

// Headers
#ifndef  MYFUNCTS_H
#define  MYFUNCTS_H
#include <string>
using namespace std;

#define PLAY   1
#define STOP   0
#define ERROR -1

// Function Prototypes
int    promptYN(string reply);
string strToUpper(string str);
string strToLower(string str);

#endif