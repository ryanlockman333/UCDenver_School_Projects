/*
Ryan Lockman
CSC 160-001
Project: HighCard
Description: Randomly generate 2 playing cards. Display the two 
			 cards and compare them to output, which is the high card.
*/

// Headers
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <sstream>

using namespace std;

int main()
{
	// Local Declarations
	string card1, card2;
	string strSuit1, strSuit2, strRank1, strRank2;
	int    suit1 = 0, suit2 = 0;
	int	   rank1 = 0, rank2 = 0;

	// Time Declaration
	srand(time(NULL));

	// Process Rand
	rank1 = rand() % 13 + 2;
	suit1 = rand() % 4 + 1;
	rank2 = rand() % 13 + 2;
	suit2 = rand() % 4 + 1;

	// Process Same Cards
	if (rank1 == rank2 && suit1 == suit2)
	{
		rank2 = rand() % 13 +2;
		suit2 = rand() % 4 + 1;
	}

	// Process rank1 High Cards
	switch (rank1)
	{
	case 11:
		strRank1 = "Jack";
		break;
	case 12:
		strRank1 = "Queen";
		break;
	case 13:
		strRank1 = "King";
		break;
	case 14: case 1:
		strRank1 = "Ace";
		break;
	default:
		stringstream ss;
		ss << rank1;
		ss >> strRank1;
	}

	// Process suit1 Suit
	switch (suit1)
	{
	case 1:
		strSuit1 = "Clubs";
		break;
	case 2:
		strSuit1 = "Diamonds";
		break;
	case 3:
		strSuit1 = "Hearts";
		break;
	case 4:
		strSuit1 = "Spades";
		break;
	default:
		strSuit1 = "ERROR SUITE";
	}

	// Process rank2 High Cards
	switch (rank2)
	{
	case 11:
		strRank2 = "Jack";
		break;
	case 12:
		strRank2 = "Queen";
		break;
	case 13:
		strRank2 = "King";
		break;
	case 14: case 1:
		strRank2 = "Ace";
		break;
	default:
		stringstream ss;
		ss << rank2;
		ss >> strRank2;
	}

	// Process suit2 Suit
	switch (suit2)
	{
	case 1:
		strSuit2 = "Clubs";
		break;
	case 2:
		strSuit2 = "Diamonds";
		break;
	case 3:
		strSuit2 = "Hearts";
		break;
	case 4:
		strSuit2 = "Spades";
		break;
	default:
		strSuit2 = "ERROR SUITE";
	}

	// Process Cards
	card1 = strRank1 + " of " + strSuit1;
	card2 = strRank2 + " of " + strSuit2;

	// Output
	cout << "Card 1: " << card1 << endl << endl;
	cout << "Card 2: " << card2 << endl << endl;

	// Process High Card Rank
	if (rank1 > rank2)
		cout << "\nCard 1 is the high card winner\n\n";
	else if (rank2 > rank1)
		cout << "\nCard 2 is the high card winner\n\n";
	else
		cout << "\nCards Tie\n\n";

	system("pause");
	return 0;
}