/*
Ryan Lockman
CSC 160-001
Project: BudgetTracker
Description: Read itemized budget items from file, ask user for actual
			 budget, and then calculate weather exceeds or within budget.
*/

// Headers
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int main()
{
	// Local Declarations
	ifstream inFile;
	ofstream outFile;
	string	 itemName1;
	double	 itemAmt1     = 0.0;
	string	 itemName2;
	double	 itemAmt2     = 0.0;
	string	 itemName3;
	double   itemAmt3     = 0.0;
	string	 itemName4;
	double   itemAmt4     = 0.0;
	double	 budgetAmt    = 0.0;
	double   itemTotals   = 0.0;
	bool	 budgetExceed = false;

	// Open inFile
	inFile.open("budget.dat");

	// Error inFile
	if (!inFile)
	{
		cout << "Error opening file\n";

		system("pause");
		return 1;
	}

	// Input inFile
	inFile >> itemName1 >> itemAmt1;
	inFile >> itemName2 >> itemAmt2;
	inFile >> itemName3 >> itemAmt3;

	// Close inFile
	inFile.close();

	// Input
	cout << "Enter actual budget: ";
	cin  >> budgetAmt;

	// Process
	itemTotals = itemAmt1 + itemAmt2 + itemAmt3;

	// Output
	cout << fixed << showpoint << setprecision(2);
	cout << endl  << endl;
	cout << left  << setw(15)  << "ITEM"    << right << setw(11) << "AMOUNT\n";
	cout << left  << setw(15)  << itemName1 << right << setw(10) << itemAmt1 << "\n";
	cout << left  << setw(15)  << itemName2 << right << setw(10) << itemAmt2 << "\n";
	cout << left  << setw(15)  << itemName3 << right << setw(10) << itemAmt3 << "\n";

	cout << "\n\nItem Totals: "  << right << setw(12) << itemTotals;
	cout << "\nActual Budget: "  << right << setw(10) << budgetAmt;
	cout << "\n\n";

	if (itemTotals > budgetAmt)
	{
		cout << "BUDGET EXCEEDED\n\n";
		budgetExceed = true;
	}
	else
	{
		cout << "\nEnter new item name:   ";
		cin  >> itemName4;
		cout << "Enter new item amount: "  ;
		cin  >> itemAmt4;
    }

	// Open outFile
	outFile.open("budget.dat");

	// Error outFile
	if (!outFile)
	{
		cout << "Error opening file\n";

	    system("pause");
	    return 2;
	}
  
	// Output outFile
	outFile << fixed << showpoint << setprecision(2);
	outFile << left  << setw(15)  << itemName1 << right << setw(10) << itemAmt1 << "\n";
	outFile << left  << setw(15)  << itemName2 << right << setw(10) << itemAmt2 << "\n";
	outFile << left  << setw(15)  << itemName3 << right << setw(10) << itemAmt3 << "\n";

	if (budgetExceed == false)
		outFile << left  << setw(15)  << itemName4 << right << setw(10) << itemAmt4 << "\n";

	// Close outFile
	outFile.close();

	system("pause");
	return 0;
}