/*
Ryan Lockman
CSC 160-001
Project: hangman
Description: Allows a user to play the game hangman.
*/

// Headers
#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

using namespace std;

// Constant Declarations
const string PHASE1 = "\n -------|    "
		              "\n |      |    "
			          "\n        |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE2 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE3 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n |      |    "
		              "\n        |    "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE4 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|      |    "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE5 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE6 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/       |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE7 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/ \\     |	  "
		              "\n        |	  "
		              "\n      -----\n";

int main()
{
	// Local Declarations
	ifstream inFile;
	string	 strWord1;
	string   strWord2;
	string   strWord3;
	char     chrGuess   = 0;
	int      intCounter = 0;
	int		 i          = 0;

	// Open inFile
	inFile.open("hangman.dat");

	// Error inFile
	if (!inFile)
	{
		cout << "Error opening file.";

		system("pause");
		return 1;
	}

	// Input inFile
	inFile >> strWord1;
	inFile >> strWord2;
	inFile >> strWord3;

	// Close inFile
	inFile.close();

	// Output inFile
	cout << "Word: " << strWord1 << endl;
	cout << "Word: " << strWord2 << endl;
	cout << "Word: " << strWord3 << endl;

	// Process Word Uppercase
	for(i = 0; i < strWord3.length(); i++)
		strWord3[i] = toupper(strWord3[i]);

	// Output inFile Word 
	cout << "\nWord to Guess: " << strWord3 << endl;
	
	// Output Man PHASE1
	cout << PHASE1 << endl;

	// Loop Game
	do
	{
		// Input Guess
		cout << "\n\nPlease enter a letter to guess: ";
		cin  >> chrGuess;
		
		// Process Guess to Uppercase
		chrGuess = toupper(chrGuess);

		// Output Guess
		cout << "\nYou entered " << chrGuess << " " << "to guess.\n\n";

		// Process Guess
		for(i = 0; i < strWord3.length(); i++)
		{	
			// Process Correct Guess
			if	   (strWord3[i] == chrGuess)
			{
					// Output Correct Guess
				    cout << chrGuess << " " << "is in the word to guess.\n";

					// Process Correct Counter
					if      (intCounter == 0)
							cout << PHASE1 << endl;
					else if (intCounter == 1)
					        cout << PHASE2 << endl;
					else if(intCounter == 2)
							cout << PHASE3 << endl;
					else if(intCounter == 3)
							cout << PHASE4 << endl;
					else if(intCounter == 4)
							cout << PHASE5 << endl;
					else if(intCounter == 5)
							cout << PHASE6 << endl;
					break;
			}
			else if(strWord3[i] != chrGuess)
			{
					// Process Count
					intCounter++;

					// Output Wrong Guess
					cout << chrGuess << " " << "is NOT in the word to guess.\n";

					// Process Wrong Counter
					if     (intCounter == 1)
						cout << PHASE2 << endl;
					else if(intCounter == 2)
						cout << PHASE3 << endl;
					else if(intCounter == 3)
						cout << PHASE4 << endl;
					else if(intCounter == 4)
						cout << PHASE5 << endl;
					else if(intCounter == 5)
						cout << PHASE6 << endl;
					else if(intCounter == 6)
					{
						cout << PHASE7 << endl;
						cout << "You guessed wrong 6 times. GAME OVER!";
					}
					break;
			}
		}
	}while(intCounter < 6);

	cin.ignore();
	cin.get();
	return 0;
}