/*
Ryan Lockman
CSC 160-001
Project: Code
Description: Prompts user for a number between 0 and 35,
			 if number is <= 9 print number, otherwise
			 outputs A through Z depending on value.
*/

// Headers
#include <iostream>

using namespace std;

int main()
{
	// Local Declarations
	int intNumber;

	// Input
	cout << "Enter a number between 0 and 35: ";
	cin  >> intNumber;

	// Process
	if	   (intNumber >= 0  && intNumber <= 9)
			cout << "You entered: "   << intNumber;
	else if(intNumber >= 10 && intNumber <= 35)
			cout << "\nYour value is: " << static_cast<char>(intNumber - 10 + 'A');
	else
			cout << "\nYou entered an incorrect number.";

	/* Test Plan
	case1: intNUmber = 3,  Prints 3
	case2: intNumber = 10, Prints A
	case3: intNumber = 34, Prints Y
	*/

	cin.ignore();
	cin.get();
	return 0;
}