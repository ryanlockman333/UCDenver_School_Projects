/*
	Ryan Lockman
	CSC 160-001
	Project: TextArt
	Description: Outputs an ASCII design I found on the internet.
*/


// Headers
#include <iostream>

using namespace std;


int main()
{
	// Statements
	cout <<	"		    O .                        " << endl;
	cout <<	"		  _/|\\_-O					   " << endl;
	cout <<	"	         ___|_______               " << endl;
	cout <<	"		/      |    \\                 " << endl;
	cout <<	"               /       |     \\       " << endl;
	cout <<	"	      #################            " << endl;
	cout <<	"	     /    _ ( )|       \\          " << endl;
	cout <<	"	    /    ( ) | |        \\         " << endl;
	cout <<	"           /    \\ |_/  |         \\  " << endl;
	cout <<	"          /____  \\|____|__________\\ " << endl;
	cout <<	"              |   |             |     " << endl;
	cout <<	"              |  / \\            |    " << endl;
	cout <<	"	      | /   \\           |drx      " << endl;
	cout <<	"              _/    /_                " << endl;

	cout << "\nSource: http://www.asciiartfarts.com/halo.html \n" << endl;

	system("PAUSE");
	return 0;

}
