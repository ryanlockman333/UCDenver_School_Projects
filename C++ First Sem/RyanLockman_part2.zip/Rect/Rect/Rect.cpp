/*
	Ryan Lockman
	CSC 160-001
	Project: Rect
	Description: This program calculates the area and perimeter of a user's rectangle.
*/

// Headers
#include <iostream>

using namespace std;

int main()
{
	// Declarations
	double length    = 0.0;
	double width     = 0.0;
	double area      = 0.0;
	double perimeter = 0.0;

	// Input
	cout << "Enter your LENGTH: ";
	cin  >> length;
	cout << "Enter your WIDTH:  ";
	cin  >> width;
	cout << endl;

	// Process
	area	  = length * width;
	perimeter = 2 * length + 2 * width;

	// Output
	cout << "AREA      = " << area << endl;
	cout << "PERIMETER = " << perimeter << endl;
	cout << endl;

	//	Test Plan
	//
	//case1: length: 2 width: 5
	//	area: 10 perimeter: 14
	//
	//case2: length: 2.5 width: 1.125
	//	area: 2.8125 permeter: 7.25
	//
	//case3: length 10 width: 5
	//	area: 50 permeter: 30


	system("PAUSE");
	return 0;

}
