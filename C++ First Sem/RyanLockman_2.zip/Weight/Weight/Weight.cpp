/*
Ryan Lockman
CSC 160-001
Project: Weight
Description: Prompts user's weight in kilograms and outputs it to pounds.
*/

// Headers
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	// Local Declarations
	double dblKilo    = 0;
	double dblPounds  = 0;
	double dblConvert = 0;

	// Input
	cout << "Enter your weight in kilograms: ";
	cin  >> dblKilo;

	// Process
	dblConvert = dblKilo * 2.2;

	// Output
	cout << fixed << setprecision(2);
	cout << "\n\nYour weigt in kilograms is: " << dblKilo    << endl;
	cout << "\nYour weight in pounds is:   "   << dblConvert << endl;
	cout << endl << endl;

	// Test Plan
	/*
	case1: kilos 100,  pounds = 220.00
	case2: kilos 125,  pounds = 275.00
	case3: kilos 175.5 pounds = 386.10
	*/

	system("pause");
	return 0;
}