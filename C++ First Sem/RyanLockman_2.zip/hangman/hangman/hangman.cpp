/*
Ryan Lockman
CSC 160-001
Project: hangman
Description: Allows a user to play the game hangman.
*/

// Headers
#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

using namespace std;

// Constants
const string PHASE1 = "\n -------|    "
		              "\n |      |    "
			          "\n        |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE2 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n        |    "
		              "\n        |    "
		              "\n        |    "
		              "\n      -----\n";
const string PHASE3 = "\n -------|    "
		              "\n |      |    "
			          "\n 0      |    "
	                  "\n |      |    "
		              "\n        |    "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE4 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|      |    "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE5 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n        |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE6 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/       |	  "
		              "\n        |	  "
		              "\n      -----\n";
const string PHASE7 = "\n -------|	  "
		              "\n |      |	  "
			          "\n 0      |	  "
	                  "\n-|-     |	  "
		              "\n/ \\     |	  "
		              "\n        |	  "
		              "\n      -----\n";

int main()
{
	// Local Declarations
	ifstream inFile;
	string	 strWord;
	char     chrGuess;

	// Output Hangman View
	cout << PHASE1 << endl;

	// Open inFile
	inFile.open("hangman.dat");

	// Error inFile
	if (!inFile)
	{
		cout << "Error opening file.";

		system("pause");
		return 1;
	}

	// Input inFile
	inFile >> strWord;

	// Output Infile
	cout << "Word from datafile: " << strWord << endl;

	// Input Guess
	cout << "\nPlease enter a letter to guess: ";
	cin  >> chrGuess;

	// Process Guess
	chrGuess = toupper(chrGuess);

	// Output Guess
	cout << "\nYou entered " << chrGuess << " " << "to guess.\n\n";

	// Close inFile
	inFile.close();

	// Output Hangman Designs
	cout << PHASE1 << endl;
	cout << PHASE2 << endl;
	cout << PHASE3 << endl;
	cout << PHASE4 << endl;
	cout << PHASE5 << endl;
	cout << PHASE6 << endl;
	cout << PHASE7 << endl;

	cin.ignore();
	cin.get();
	return 0;
}