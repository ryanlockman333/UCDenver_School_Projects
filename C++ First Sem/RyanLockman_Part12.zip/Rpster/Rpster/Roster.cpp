/*
Ryan Lockman
CSC 160-001
Project: Roster
Description: Stores a list of names in an array as a roster.
*/

// Headers
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// Constants
const int MAX = 35;

int main()
{
	// Declarations
	ifstream inFile;
	string   names[MAX];
	string   tmpName;
	string   nameToFind;
	string   gamePlay = "N";
	bool     found	  = false;
	int	     used	  = 0;

	// Open File
	inFile.open("roster.txt");

	// Error Open File
	if(!inFile)
	{
		cout << "Error opening file\n";

		cin.get();
		return -1;
	}

	// Input File
	inFile >> tmpName;

	// Process File
	while(!inFile.fail())
	{
		if(used < MAX)
		{
			names[used] = tmpName;
			used++;
		}
		else
			cout << "Skipped data";

		// Input File
		inFile >> tmpName;
	}

	// Close File
	inFile.close();

	// Loop Program
	do
	{
		// Print Names
		for(int i = 0; i < used; i++)
			cout << "\n" << names[i];

		// Input Name To Find
		cout << "\n\nEnter a name to find: ";
		cin  >> nameToFind;

		found = false;
		for(int i = 0; i < used; i++)
		{
			if(nameToFind == names[i])
			   found = true;
		}
	
		// Process Found
		if(found)
			cout << "\nFound Name\n";
		else
			cout << "\nName Not Found\n";

		// Input Again
		cout << "\nDo you want to do it again (Y/N): ";
		cin  >> gamePlay;
		cout << endl;
	}
	while(gamePlay != "N");

	cout << endl << endl;

	cin.get();
	return 0;
}