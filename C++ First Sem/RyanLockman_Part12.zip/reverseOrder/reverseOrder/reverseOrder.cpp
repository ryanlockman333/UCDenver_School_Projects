/*
Ryan Lockman
CSC 160-001
Project: reverseOrder
Description: Using arrays prints numbers in order and then reverse.
*/

// Headers
#include <iostream>

using namespace std;

// Constants
const int MAX = 10;

int main()
{
	// Declarations
	int numbers[MAX] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
	int tmp = 0;

	/*
	numbers[0] = 10;
	numbers[1] = 20;
	numbers[2] = 30;
	numbers[3] = 40;
	numbers[4] = 50;
	numbers[5] = 60;
	numbers[6] = 70;
	numbers[7] = 80;
	numbers[8] = 90;
	numbers[9] = 100;
	*/

	// Output Regular Order
	cout << "Printed in Order\n";

	// Print Regular Order
	for(int i = 0; i < MAX; i++)
		cout << numbers[i] << "\t";

	// Process Reverse Order
	for(int i = 0; i < (MAX / 2); i++)
	{
		tmp = numbers[i];
		numbers[i] = numbers[MAX - i - 1];
		numbers[MAX - i - 1] = tmp;
	}

	// Output Reverse Order
	cout << "\n\nPrinted in Reversed Order\n";

	// Print Reverse Order
	for(int i = 0; i < MAX; i++)
		cout << numbers[i] << "\t";

	cin.get();
	return 0;
}