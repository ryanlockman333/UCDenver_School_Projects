/*
Ryan Lockman
CSC 160-001
Project: MathPuzzle
Description: Math puzzle to figure your age,
			 given non-related inputs using system functions.
*/

// Headers
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <sstream>

using namespace std;

int main()
{
	// Local Declarations
	int    intDinner =  0;
	int    intAnswer =  0;
	int    intByear  =  0;
	char   chrDinner = '0';
	string stgAge;

	// Time Declaration
	srand( time(NULL) );

	// Input
	//cout << "Enter number of times you eat out a week: ";
	//cin  >> intDinner;

	cout << "\nEnter year of birth: ";
	cin  >> intByear;

	// Process
	intDinner  = fmod(rand(), 7.0) + 1;
	intAnswer  = intDinner;
	intAnswer *= 2;
	intAnswer  = (intAnswer + 5) * 50;
	intAnswer += 1762;
	intAnswer -= intByear;
	intAnswer  = intAnswer;

	// String Insertion
	stringstream ss;

	ss << intAnswer;
	chrDinner = ss.get();
	ss >> stgAge;

	// Output
	cout << "\n\nAge:  " << stgAge
		 << "\nDinner: " << chrDinner;

	system("pause");
	return 0;
}