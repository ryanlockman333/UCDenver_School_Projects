/*
Ryan Lockman
CSC160-001
Project: Banner
Description: Outputs your initials in banner format.
*/


/*Headers*/
#include <iostream>
using namespace std;


int main()
{
	/*Statements*/
	cout << "    R \t    DL    \n";
	cout << "    R \t   DL	   \n";
	cout << "   R  \t      DL  \n";
	cout << "     R\t    D  L  \n";
	cout << "   R  \t   D   L  \n";

	cout << endl << endl;

	system("PAUSE");
	return 0;

}
