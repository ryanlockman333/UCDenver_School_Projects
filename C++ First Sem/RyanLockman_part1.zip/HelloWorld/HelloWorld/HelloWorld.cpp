/*
 Ryan Lockman
 CSC160-001
 Project: HelloWorld
 Description: Prints Hello World! on screen.
 */

/*Headers*/
#include <iostream>
using namespace std;

int main()
{
	/*Statements*/
	cout << "Hello World!" << endl;

	system("PAUSE");
	return 0;

}
