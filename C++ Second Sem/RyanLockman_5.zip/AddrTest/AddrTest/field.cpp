/*
Ryan Lockman
Field.h
Description: Field class definitions.
*/

// Headers
#include "Field.h"

// Stream Operators
istream& operator>>(istream &is, Field &fld) {
	if(is.peek() == '\n')
		is.ignore();
	getline(is, fld, '\n');
	return is;
}

ifstream& operator>>(ifstream &ifs, Field &fld) {
	getline(ifs, fld, ',');
	if(ifs.peek() == '\n')
		ifs.ignore();
	return ifs;
}