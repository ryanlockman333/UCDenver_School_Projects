/*
Ryan Lockman
contact.h
Desription: Contact class prototypes.
*/

#ifndef CONTACT_H
#define CONTACT_H

// Headers
#include "name.h"
#include "address.h"

class Contact {
public:
	// Constructors
	Contact();
	Contact(Field phoneIn, Field birthIn, Field emailIn, Field picIn);

	// Set Member Fuctions
	void SetPhone   (Field phoneIn)     { phone = phoneIn; }
	void SetBirthday(Field birthIn)     { birth = birthIn; }
	void SetEmail   (Field emailIn)     { email = emailIn; }
	void SetPicture (Field picIn)       { pic   = picIn; }
	void SetNameObj (Name nameObjIn)    { NameObj = nameObjIn; }
	void SetAddrObj (Address addrObjIn) { AddrObj = addrObjIn; }

	// Get Member Functions
	Field   GetPhone()	  const { return phone; }
	Field   GetBirthday() const { return birth; }
	Field   GetEmail()    const { return email; }
	Field   GetPicture()  const { return pic; }
	Name    GetNameObj()  const { return NameObj; }
	Address GetAddrObj()  const { return AddrObj; }


	// Relational Opertors
	friend bool operator==(const Contact &lhs, const Contact &rhs); // actual parameter
	friend bool operator!=(const Contact &lhs, const Contact &rhs) { return !operator==(lhs, rhs); }
	friend bool operator< (const Contact &lhs, const Contact &rhs); // actual parameter
	friend bool operator> (const Contact &lhs, const Contact &rhs) { return  operator< (rhs, lhs); }
	friend bool operator<=(const Contact &lhs, const Contact &rhs) { return !operator> (lhs, rhs); }
	friend bool operator>=(const Contact &lhs, const Contact &rhs) { return !operator< (lhs, rhs); }

	// Stream Operators
	friend istream&  operator>>(istream &is, Contact &contObj);
	friend ifstream& operator>>(ifstream &ifs, Contact &contObj);
	friend ostream&  operator<<(ostream &os, const Contact &contObj);
	friend ofstream& operator<<(ofstream &ofs, const Contact &contObj);

protected:
	// Data Members
	Name    NameObj;
	Address AddrObj;
	Field   phone, birth, email, pic;
};

#endif