/*
Ryan Lockman
contact.h
Desription: Contact class prodefinitions.
*/

// Headers
#include "contact.h"

// Constructors
Contact::Contact() {
	phone = "Unknown";
	birth = "Unknown";
	email = "Unknown";
	pic   = "Unknown";
}

Contact::Contact(Field phoneIn, Field birthIn, Field emailIn, Field picIn) {
	SetPhone(phoneIn);
	SetBirthday(birthIn);
	SetEmail(emailIn);
	SetPicture(picIn);
}

// Relational Opertors
bool operator==(const Contact &lhs, const Contact &rhs) {
	return(lhs.GetNameObj() == rhs.GetNameObj());
}

bool operator<(const Contact &lhs, const Contact &rhs) {
	return(lhs.GetNameObj() < rhs.GetNameObj());
}

// Stream Operators
istream&  operator>>(istream &is, Contact &contObj) {
	Field   fld;
	Name    tmpName;
	Address tmpAddress;

	is  >> tmpName;
	contObj.SetNameObj(tmpName);
	is  >> tmpAddress;
	contObj.SetAddrObj(tmpAddress);

	cout << "Please enter Phone Number:   ";
	is   >> fld;
	contObj.SetPhone(fld);
	cout << "Please enter Birthday:       ";
	is   >> fld;
	contObj.SetBirthday(fld);
	cout << "Please enter E-mail Address: ";
	is   >> fld;
	contObj.SetEmail(fld);
	cout << "Please enter Picture:        ";
	is   >> fld;
	contObj.SetPicture(fld);

	return is;
}

ifstream& operator>>(ifstream &ifs, Contact &contObj) {
	Field   fld;
	Name    tmpName;
	Address tmpAddress;

	ifs >> tmpName;
	contObj.SetNameObj(tmpName);
	ifs >> tmpAddress;
	contObj.SetAddrObj(tmpAddress);

	ifs >> fld;
	contObj.SetPhone(fld);
	ifs >> fld;
	contObj.SetEmail(fld);
	ifs >> fld;
	contObj.SetBirthday(fld);
	ifs >> fld;
	contObj.SetPicture(fld);

	return ifs;
}

ostream&  operator<<(ostream &os, const Contact &contObj) {
	os << contObj.GetNameObj();
	os << contObj.GetAddrObj();
	os << contObj.GetPhone() + '\n' + contObj.GetBirthday() + '\n'
		  + contObj.GetEmail() + '\n' + contObj.GetPicture() + '\n';
	return os;
}

ofstream& operator<<(ofstream &ofs, const Contact &contObj) {
	ofs << contObj.GetNameObj();
	ofs << contObj.GetAddrObj();
	ofs << contObj.GetPhone() + ',' + contObj.GetEmail() + ','
		   + contObj.GetBirthday() + ',' + contObj.GetPicture() + ',';
	return ofs;
}