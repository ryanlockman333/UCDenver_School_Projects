/*
Ryan Lockman
LinkList.h
Description: LinkList template class prototypes.
*/

#ifndef LINKLIST_H
#define LINKLIST_H

// Headers
#include "CategorizedContact.h"
#include "node.h"

template<class Type> class LinkList {
public:
	// Default Constructor
	LinkList();

	// Copy Constructor
	LinkList(const LinkList<Type> &otherList);

	// Assignment Operator
	LinkList<Type>& operator=(const LinkList<Type> &otherList);

	// Destructor
	~LinkList() { Free(); };

	// Get Member Functions
	int  GetUsed()     const { return used; }
	bool IsListEmpty() const { return(First == NULL); }

	// Set Member Functions
	void SetOrder();

	// Other Member Functions
	void InitializeList();
	void AddItem();
	void RemoveItem();
	void PrintAddrBookMenu() const;
	void PrintCategoryList();
	void PrintLength() const;
	void ReadAddrBook(const Field fileName);
	void WriteToAddrBook(Field fileName);

private:
	// Private Data Members
	Node<Type> *First, *Last;
	int  used;
	bool asc, desc;

	// Private Member Functions
	void AddNode     (const Type &nodeToAdd);
	void RemoveNode  (const Type &nodeToRemove);
	void CopyList    (const LinkList<Type> &otherList);
	Node<Type>* Alloc(const Type &nodeIn);
	void Free();
};

#include "LinkList.tem"
#endif