/*
Ryan Lockman
address.cpp
Description: Address class prototypes.
*/

// Headers
#include "address.h"

// Constructors
Address::Address() {
	street = "Unknown";
	city   = "Unknown";
	state  = "Unknown";
	zip    = "Unknown";
}

Address::Address(Field streetIn, Field cityIn, Field stateIn, Field zipIn) {
	   SetStreet(streetIn);
	   SetCity(cityIn);
	   SetState(stateIn);
	   SetZip(zipIn);
}

// Stream Operators
istream& operator>>(istream &is, Address &addrObj) {
	Field fld;

	cout << "Please enter Street Address: ";
	is   >> fld;
	addrObj.SetStreet(fld);
	cout << "Please enter City:           ";
	is   >> fld;
	addrObj.SetCity(fld);
	cout << "Please enter State(AB):      ";
	is   >> fld;
	addrObj.SetState(fld);
	cout << "Please enter Zip Code:       ";
	is   >> fld;
	addrObj.SetZip(fld);

	return is;
}

ifstream& operator>>(ifstream &ifs, Address &addrObj) {
	Field fld;

	ifs >> fld;
	addrObj.SetStreet(fld);
	ifs >> fld;
	addrObj.SetCity(fld);
	ifs >> fld;
	addrObj.SetState(fld);
	ifs >> fld;
	addrObj.SetZip(fld);

	return ifs;
}

ostream& operator<<(ostream &os, const Address &addrObj) {
	os << addrObj.GetStreet()+ '\n' + addrObj.GetCity() +
		  ", " + addrObj.GetState() + " " + addrObj.GetZip() + '\n';
	return os;
}

ofstream& operator<<(ofstream &ofs, const Address &addrObj) {
	ofs << addrObj.GetStreet() + ',' + addrObj.GetCity() + ','
		   + addrObj.GetState() + ',' + addrObj.GetZip() + ',';
	return ofs;
}
