/*
Ryan Lockman
Field.h
Description: Field class prototypes.
*/

#ifndef FIELD_H
#define FIELD_H

// Headers
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class Field: public string {
public:
	// Constructors
	Field()           : string()    { }
	Field(string str) : string(str) { }

	// Copy Constructor
	Field(const char *chrStr) : string(chrStr) { }

	// Stream Operators
	friend istream&  operator>>(istream &is, Field &fld);
	friend ifstream& operator>>(ifstream &ifs, Field &fld);
};

#endif