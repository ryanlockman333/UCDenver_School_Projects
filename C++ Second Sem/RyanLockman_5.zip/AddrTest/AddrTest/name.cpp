/*
Ryan Lockman
name.h
Description: Name class definitions.
*/

// Headers
#include "name.h"

// Constructors
Name::Name() {
	firstName = "Unknown";
	lastName  = "Unknown";
}

Name::Name(Field fNameIn, Field lNameIn) {
	SetFirstName(fNameIn);
	SetLastName(lNameIn);
}

// Relational Operators
bool operator==(const Name &lhs, const Name &rhs) {
	return(StrToUpper( lhs.GetFirstName() )  == StrToUpper( rhs.GetFirstName() )
		&& StrToUpper( lhs.GetLastName()  )  == StrToUpper( rhs.GetLastName()  ));
}

bool operator< (const Name &lhs, const Name &rhs) {
	return(StrToUpper( lhs.GetLastName() + lhs.GetFirstName() ) < StrToUpper( rhs.GetLastName() + rhs.GetFirstName() ));
}

// Stream Operators
istream& operator>>(istream &is, Name &nameObj) {
	Field fld;

	cout << "\nPlease enter First name:     ";
	is   >> fld;
	nameObj.SetFirstName(fld);
	cout << "Please enter Last name:      ";
	is   >> fld;
	nameObj.SetLastName(fld);

	return is;
}

ifstream& operator>>(ifstream &ifs, Name &nameObj) {
	Field fld;

	ifs >> fld;
	nameObj.SetFirstName(fld);
	ifs >> fld;
	nameObj.SetLastName(fld);

	return ifs;
}

ostream& operator<<(ostream &os, const Name &nameObj) {
	os << nameObj.GetLastName() + ", " + nameObj.GetFirstName() + '\n';
	return os;
}

ofstream& operator<<(ofstream &ofs, const Name &nameObj) {
	ofs << nameObj.GetFirstName() + ',' + nameObj.GetLastName() + ',';
	return ofs;
}

// Non-Member Functions
Field StrToUpper(Field fld) {
	Field ans = fld;

	for(int i = 0; i < fld.length(); i++)
		ans[i] = toupper(fld[i]);

	return ans;
}