/*
Ryan Lockman
CSC 161-001
Project: addrtest.cpp
Description: Address book to store contacts.
*/

// Headers
#include "LinkList.h"

int main() {
	// Declarations
	LinkList<CategorizedContact> Book;
	int choice = 0;

	Book.ReadAddrBook("addrbook.csv");
	do {
		Book.PrintAddrBookMenu();
		cout << "Please make a choice: ";
		cin  >> choice;

		switch(choice) {
		case 1:
			Book.AddItem();
			break;
		case 2:
			Book.PrintLength();
			break;
		case 3:
			Book.PrintCategoryList();
			break;
		case 4:
			Book.RemoveItem();
			break;
		case 5:
			Book.WriteToAddrBook("addrbook.csv");
			Book.SetOrder();
			Book.ReadAddrBook("addrbook.csv");
		case 6:
			Book.WriteToAddrBook("addrbook.csv");
			break;
		}
	}while(choice != 6);

	return 0;
}