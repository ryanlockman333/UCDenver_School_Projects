 /*
Ryan Lockman
Node.h class template prototypes.
*/

#ifndef NODE_H
#define NODE_H

template <class Type> class Node {
public:
	// Constructors
	Node()			  { next = NULL; };
	Node(Type dataIn) { data = dataIn; next = NULL; }

	// Public Data Members
	Type        data;
	Node<Type> *next;
};

#include "node.tem"
#endif