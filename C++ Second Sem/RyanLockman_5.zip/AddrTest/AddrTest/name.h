/*
Ryan Lockman
name.h
Description: Name class prototypes.
*/

#ifndef NAME_H
#define NAME_H

// Headers
#include "field.h"

class Name {
public:
	// Constructors
	Name();
	Name(Field fNameIn, Field lNameIn);

	// Set Member Functions
	void SetFirstName(Field fNameIn) { firstName = fNameIn; }
	void SetLastName (Field lNameIn) { lastName  = lNameIn; }

	// Get Member Functions
	Field GetFirstName() const { return firstName; }
	Field GetLastName()  const { return lastName; }

	// Relational Opertors
	friend bool operator==(const Name &lhs, const Name &rhs); // actual parameter
	friend bool operator!=(const Name &lhs, const Name &rhs) { return( !operator==(lhs, rhs) ); }
	friend bool operator< (const Name &lhs, const Name &rhs); // actual parameter
	friend bool operator> (const Name &lhs, const Name &rhs) { return(  operator< (rhs, lhs) ); }
	friend bool operator<=(const Name &lhs, const Name &rhs) { return( !operator> (lhs, rhs) ); }
	friend bool operator>=(const Name &lhs, const Name &rhs) { return( !operator< (lhs, rhs) ); }
	// Stream Operators
	friend istream&  operator>>(istream &is, Name &nameObj);
	friend ifstream& operator>>(ifstream &ifs, Name &nameObj);
	friend ostream&  operator<<(ostream &os, const Name &nameObj);
	friend ofstream& operator<<(ofstream &ofs, const Name &nameObj);
	
private:
	// Data Members
	Field firstName, lastName;
};

// Non-Member Functions
Field StrToUpper(Field fld);

#endif