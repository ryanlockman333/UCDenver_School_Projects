
/*
Ryan Lockman
categorizedContact.h class definitions.
*/

// Headers
#include "categorizedContact.h"

// Set Member Functions
void CategorizedContact::SetCategory(Field categoryIn) {
	category = categoryIn;
	if(categoryIn == "1")
		category = "Business";
	else if(categoryIn == "2")
		category = "Colleague";
	else if(categoryIn == "3")
		category = "Family";
	else if(categoryIn == "4")
		category = "Friend";
	else if(categoryIn == "5")
		category = "School";
}

// Other Member Functions
void CategorizedContact::PrintCategoryMenu() const {
	cout << "\n<<<<<<<<<<Contact Categorys>>>>>>>>>>\n"
		 << "(1) Business\n"
		 << "(2) Colleagues\n"
		 << "(3) Family\n"
		 << "(4) Friends\n"
		 << "(5) School\n\n";
}

// Stream Operators
istream& operator>>(istream &is, CategorizedContact &catContObj) {
	Field   fld;
	Contact tmpContact;

	catContObj.PrintCategoryMenu();
	cout << "\nPlease choose Contact's category: ";
	is   >> fld;
	catContObj.SetCategory(fld);

	is >> tmpContact;
	catContObj.SetNameObj(tmpContact.GetNameObj());
	catContObj.SetAddrObj(tmpContact.GetAddrObj());
	catContObj.SetPhone(tmpContact.GetPhone());
	catContObj.SetEmail(tmpContact.GetEmail());
	catContObj.SetBirthday(tmpContact.GetBirthday());
	catContObj.SetPicture(tmpContact.GetPicture());

	return is;
}

ifstream& operator>>(ifstream &ifs, CategorizedContact &catContObj) {
	Field   fld;
	Contact tmpContact;

	ifs >> fld;
	catContObj.SetCategory(fld);
	ifs >> tmpContact;
	catContObj.SetNameObj(tmpContact.GetNameObj());
	catContObj.SetAddrObj(tmpContact.GetAddrObj());
	catContObj.SetPhone(tmpContact.GetPhone());
	catContObj.SetEmail(tmpContact.GetEmail());
	catContObj.SetBirthday(tmpContact.GetBirthday());
	catContObj.SetPicture(tmpContact.GetPicture());

	return ifs;
}

ostream& operator<<(ostream &os, const CategorizedContact &catContObj) {
	Contact tmpContact;

	tmpContact = catContObj;
	os << catContObj.GetCategory() + '\n';
	os << tmpContact;
	return os;
}

ofstream& operator<<(ofstream& ofs, const CategorizedContact &catContObj) {
	Contact tmpContact;

	tmpContact = catContObj;
	ofs << catContObj.GetCategory() + ',';
	ofs << tmpContact;
	return ofs;
}