/*
Ryan Lockman
categorizedContact.h class prototypes.
*/

#ifndef CATEGORIZEDCONTACT_H
#define CATEGORIZEDCONTACT_H

// Headers
#include "contact.h"

class CategorizedContact: public Contact {
public:
	// Constructors
	CategorizedContact()             	 { category = "Unknown"; }
	CategorizedContact(Field categoryIn) { SetCategory(categoryIn); }

	// Set Member Functions
	void SetCategory(Field categoryIn);

	// Get Member Functions
	Field GetCategory() const { return category; }

	// Other Member Functions
	void PrintCategoryMenu() const;

	// Stream Operators
	friend istream&  operator>>(istream &is, CategorizedContact &catContObj);
	friend ifstream& operator>>(ifstream &ifs, CategorizedContact &catContObj);
	friend ostream&  operator<<(ostream &os, const CategorizedContact &catContObj);
	friend ofstream& operator<<(ofstream& ofs,  const CategorizedContact &catContObj);

private:
	// Data Members
	Field category;
};

#endif