/*
Ryan Lockman
CSC 160-001
Project: NumTest
Description: Using NumList dynamic data structure, have a collection of doubles.
*/

#include <iostream>
using namespace std;
#include "NumList.h"

void testFunction();

int main() {
	testFunction();

	cin.get();
	return 0;
}

/*
void function(NumList obj) {
	// copy constructor for pass by value arguments
}

NumList function2() {
	// copy constructor, return of function
}
*/

void testFunction() {
	NumList Money;
	Money.debugOn();
	Money.addItem(10.00);
	Money.addItem(7.5);
	Money.addItem(11.25);
	Money.addItem(15.75);
	Money.print();

	NumList Budget;
	Budget.debugOn();
	Budget = Money;  // assignment operator
	Budget.print();
}