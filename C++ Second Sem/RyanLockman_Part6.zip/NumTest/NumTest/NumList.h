/*
Ryan Lockman
NumList.h class declarations.
*/

#ifndef NUMLIST_H
#define NUMLIST_H

// Headers
#include <iostream>
#include <cstdlib>
#include <string>
#include <algorithm>
using namespace std;

class NumList {
public:
	// Default Constructor
	NumList();

	// Copy Constructor
	NumList(const NumList& source);

	// Assignment Operator
	NumList& operator=(const NumList& source);

	// Destructor
	~NumList();

	// Get Member Functions
	int getUsed() const { return used; }
	int getMax()  const { return max; }

	// Other Member Functions
	void addItem(double itemToAdd);
	void removeItem(double itemToRemove);
	void removeAt(int indexToRemove);
	int  findIndexOfItem(double itemToFind);
	void print();
	void readFile(string fileName);
	void writeFile(string fileName);

	void debugOn()  { debug = true; }
	void debugOff() { debug = false; }

private:
	// Data Members
	bool    debug;
	double* ptr;
	int     used;
	int     max;

	// Private Member Functions
	void alloc(int sizeIncrease);
	void free();
};

#endif