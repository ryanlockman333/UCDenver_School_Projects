/*
Ryan Lockman
NumList.h class defenitions.
*/

// Headers
#include "NumList.h"

// Default Constructor
NumList::NumList() {
	debug = false;
	ptr   = NULL;
	used  = 0;
	max   = 0;
}

// Copy Constructor
NumList::NumList(const NumList& source) {
	ptr   = NULL;
	used  = 0;
	max   = 0;
	debug = false;

	for(int i = 0; i < source.used; i++)
		addItem(source.ptr[i]);
}

// Assignment Operator
NumList& NumList::operator=(const NumList& source) {
	if(this == &source) // checking for self assignment
		return(*this);

	free(); // free up existing memory

	ptr   = NULL;
	used  = 0;
	max   = 0;

	for(int i = 0; i < source.used; i++)
		addItem(source.ptr[i]);

	return(*this);
}

// Destructor
NumList::~NumList() {
	if(debug)
		cout << "\nIn destructor\n";
	free();
}

// Other Member Functions
void NumList::addItem(double itemToAdd) {
	if(used >= max)
		alloc(2);
	ptr[used++] = itemToAdd;
}

void NumList::removeItem(double itemToRemove) {
	int indexToRemove = findIndexOfItem(itemToRemove);
	removeAt(indexToRemove);
}

void NumList::removeAt(int indexToRemove) {
	if(indexToRemove != -1) 
		ptr[indexToRemove] = ptr[--used];
}

int NumList::findIndexOfItem(double itemToFind) {
	int indexToFind = -1;
	for(int i = 0; i < used; i++)
		if(ptr[i] == itemToFind) {
			indexToFind = i;
			break;
		}

	return indexToFind;
}

void NumList::print() {
	int count = 0;
	for(int i = 0; i < used; i++) {
		cout << ++count << ". " << ptr[i];

		if(debug)
			cout << "\t" << &ptr[i];
		cout << endl;
	}
}

void NumList::readFile(string fileName) {
	// same as project 1 and 2 but get the catagory
}

void NumList::writeFile(string fileName) {
	// same as from project 1 and 2
}

// Private Member Functions
void NumList::alloc(int sizeIncrease) {
	if(debug)
		cout << "\nInside of alloc\n";
	double* tmp = NULL;
	max += sizeIncrease;
	tmp = new double[max];
	copy(ptr, ptr+used, tmp); // copy algorithm function
	free();
	ptr = tmp;
}

void NumList::free() {
	if(debug)
		cout << "\nInside of free\n";
	if(ptr != NULL) {
		delete [] ptr;
		ptr = NULL;
	}
}