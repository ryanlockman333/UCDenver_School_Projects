/*
Ryan Lockman
CSC 160-001
Project: Stack Overflow
Description: Program to show example of security risk with a buffer overflow.
*/

// Headers
#include <iostream>
#include <string>

// Constants
const int PIN_LEN = 4;

// Function Prototypes
int getPin();
int charArrayToInt(char digits[]);

int main() {
	std::cout << "\nYour pin is: " << getPin();
	std::cin.ignore();
	std::cin.get();
	return 0;
}

int getPin() {
	std::string pinStr;
	char digits[PIN_LEN];

	std::cout << "Enter your pin: ";
	std::cin  >> pinStr;

	for(int i = 0; i < PIN_LEN; i++) // add 1 < PIN_LEN; instead of pinStr.length(). to fix overflow
		digits[i] = pinStr[i];

	return charArrayToInt(digits);
}

int charArrayToInt(char digits[]) {
	int ans = 0;

	for(int i = 0; i < PIN_LEN; i++) {
		ans *= 10;
		ans += digits[i] - '0';
	}
	return ans;
}