/*
Ryan Lockman
Node.h class prototypes
*/

#ifndef NODE_H
#define NODE_H

// Headers
#include <cstdlib>

class Node {
public:
	// Constructors
	Node();
	Node(double dataIn);

	// Public Data Members
	double data;
	Node  *next;
};

#endif