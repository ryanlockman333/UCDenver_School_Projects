/*
Ryan Lockman
LinkList.h class defenitions
*/

// Headers
#include "LinkList.h"

// Constructors
LinkList::LinkList() {
	first = NULL;
	last  = NULL;
	used  = 0;
	debug = false;
	asc   = false;
	desc  = false;
}

// Copy Constructor
LinkList::LinkList(const LinkList & source) {
	first = NULL;
	last  = NULL;
	debug = false;
	asc = source.asc;
	desc = source.desc;
	used = 0;
	copyList(source.first);
}

// Assignment Operator
LinkList& LinkList::operator=(const LinkList &source) {
	if(this == &source)
		return *this;
	free();

	first = NULL;
	last  = NULL;
	debug = false;
	asc = source.asc;
	desc = source.desc;
	used = 0;
	copyList(source.first);
}

void LinkList::copyList(Node* cursor) {
	if(cursor != NULL) {
		addItem(cursor->data);
		copyList(cursor->next);
	}
}

// Set Member Functions
void LinkList::setAsc() {
	if(first == NULL) {
		asc  = true;
		desc = false;
	}
}

void LinkList::setDesc() {
	if(first == NULL) {
		asc  = false;
		desc = true;
	}
}

// Other Member Functions
void LinkList::addItem(double itemToAdd) {
	Node *tmp = alloc(itemToAdd);

	if(first == NULL) {
		first = tmp;
		last  = tmp;
	}
	else if(asc)
		addAsc(tmp);
	else if(desc)
		addDesc(tmp);
	else {
		last->next = tmp;
		last = tmp;
	}
	used++;
}

void LinkList::removeItem(double itemToRemove) {
	Node *nodeToRemove = findNode(itemToRemove);
	Node *prevPtr      = NULL;

	if(nodeToRemove == first)
		removeFirst();
	else {
		prevPtr = findPrevious(nodeToRemove);
		removeNode(prevPtr);
	}
}

void LinkList::removeFirst() {
	Node *cursor = first;

	if(cursor != NULL) {
		first = cursor->next;
		delete cursor;
		used--;
	}
	else
        last = NULL;
}

// Function should not be called if tyring to remove the first node - call removeFirst()
void LinkList::removeNode(Node *previousPtr) {
	Node *nodeToRemove = previousPtr->next;

	previousPtr->next = nodeToRemove->next;
	delete nodeToRemove;
	used--;
}

void LinkList::print(bool numbered) {
	Node *cursor = NULL;
	int   count  = 0;

	if(numbered) {
		for(cursor = first; cursor != NULL; cursor = cursor->next) {
			std::cout << ++count << ". " << cursor->data;

			if(debug)
				std::cout << "\t" << cursor;

			std::cout << std::endl;
		}
	}
	else
		print(first);
}

void LinkList::readFile(std::string fileName) {

}

void LinkList::writeFile(std::string fileName) {

}

void LinkList::addAsc (Node *tmp) {

}

void LinkList::addDesc(Node *tmp) {

}

// Private Member Functions
void LinkList::free() {
	while(first != NULL)
		removeFirst();
}

Node* LinkList::alloc(double itemToAdd) {
	Node* tmp = new Node(itemToAdd);
	return tmp;
}

Node* LinkList::findNode(double dateIn) {
	Node *cursor = NULL;

	for(cursor = first; cursor != NULL; cursor = cursor->next)
		if(dateIn == cursor->data)
			break;
	return cursor;
}

Node* LinkList::findPrevious(Node *nodeToFind) {
	Node *prevPtr = NULL;

	if(nodeToFind != first)
		for(prevPtr = first; prevPtr != NULL; prevPtr = prevPtr->next)
			if(prevPtr->next == nodeToFind)
				break;
	return prevPtr;
}

void LinkList::print(Node *cursor) {
	if(cursor != NULL) {
		std::cout << cursor->data;

		if(debug)
			std::cout << "\t" << cursor;

		std::cout << std::endl;
		print(cursor->next);
	}

}