/*
Ryan Lockman
LinkList.h class prototypes
*/

#ifndef LINKLIST_H
#define LINKLIST_H

// Headers
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include "Node.h"

class LinkList {
public:
	// Constructors
	LinkList();
	~LinkList() { free(); }

	// Copy Constructor
	LinkList(const LinkList & source);

	// Assignment Operator
	LinkList& operator=(const LinkList &source);

	void LinkList::copyList(Node* cursor);

	// Get Member Functions
	double getItem(int itemNum) { return 0.0; }
	int    getUsed() const      { return used; };

	// Set Member Functions
	void debugOn()  { debug = true; }
	void debugOff() { debug = false; }
	void setAsc();  // EC
	void setDesc(); // EC

	// Other Member Functions
	void addItem   (double itemToAdd);
	void removeItem(double itemToRemove);
	void removeFirst();
	void removeNode(Node *previousPtr);
	void addAsc    (Node *tmp);
	void addDesc   (Node *tmp);
	void print     (bool numbered = true);
	void readFile  (std::string fileName);
	void writeFile (std::string fileName);

private:
	// Data Members
	Node *first;
	Node *last;
	int   used;
	bool  debug;
	bool  asc;
	bool  desc;

	// Private Member Functions
	void  free();
	Node* alloc(double itemToAdd);
	Node* findNode(double dateIn);
	Node* findPrevious(Node *nodeToFind);
	void  print(Node *cursor);   
};

#endif