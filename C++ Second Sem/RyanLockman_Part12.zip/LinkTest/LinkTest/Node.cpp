/*
Ryan Lockman
Node.cpp class definitions
*/

// Headers
#include "Node.h"

// Constructos
Node::Node() {
	data = 0.0;
	next = NULL;
}

Node::Node(double dataIn) {
	data = dataIn;
	next = NULL;
}