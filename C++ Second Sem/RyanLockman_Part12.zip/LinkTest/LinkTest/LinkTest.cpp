/*
Ryan Lockman
CSC 160-001
Proect: LinkTest
Description: Store doubles in a link list data structure.
*/

// Headers
#include <iostream>
#include "LinkList.h"

int main() {
	// Declarations
	LinkList collection;

	// Set Debug
	collection.debugOn();

	// Member Functions
	collection.addItem(99);
	collection.addItem(88);
	collection.addItem(77);
	collection.addItem(66);
	collection.addItem(55);
	collection.addItem(44);

	std::cout << "Added 6 items.\n";
	collection.print();


	std::cout << "\n\nCollection 2\n";
	LinkList coll2(collection);
	coll2.debugOn();
	coll2.print(false);

	std::cout << "\n\nCollection 3\n";
	LinkList coll3 = coll2;
	coll3.debugOn();
	coll3.print(false);


	std::cin.get();
	return 0;
}