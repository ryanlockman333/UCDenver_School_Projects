/*
Ryan Lockman
Bintree.cpp class definitions.
*/

// Headers
#include "BinTree.h"

// Default Constructor
BinTree::BinTree() {
	root  = NULL;
	used  = 0;
	debug = false;
}

// Copy Constructor
BinTree::BinTree(const BinTree &source) {
	root  = NULL;
	used  = 0;
	debug = false;
	copyTree(source.root);
}

// Destructor
BinTree::~BinTree() {
	free(root);
	root = NULL;
}

// Assignment Operator
BinTree& BinTree::operator=(const BinTree &source) {
	if(&source == this)
		return *this;

	free(root);
	root  = NULL;
	used  = 0;
	copyTree(source.root);

	return *this;
}

// Other Member Functions
void BinTree::addItem(string itemToAdd) {
	BinNode *tmpNode = alloc(itemToAdd);
	BinNode *cursor  = root;

	if(root == NULL)
		root = tmpNode;
	else
		while(cursor != NULL) 
			if(tmpNode->data <= cursor->data) // left side
				if(cursor->left == NULL) {
					cursor->left = tmpNode;
					cursor       = NULL;
				}
				else
					cursor = cursor->left;
			else                              // right side
				if(cursor->right == NULL) {
					cursor->right = tmpNode;
					cursor        = NULL;
				}
				else
					cursor = cursor->right;
	used++;
}

void BinTree::printAll() {
	int count = 0;
	cout << "\nTree: \n";
	printInOrder(root, count);
	cout << "\n\n";
}

void BinTree::readFile(string fileName) {

}

void BinTree::writeFile(string fileName) {
	ofstream outFile(fileName.c_str());
	// chack if file openeded for writing

	writeFile(root, outFile);
	outFile.close();
}

void BinTree::inOrderTraverse(void process(int, string&)) {
	int count = 0;
	inOrderTraverse(root, process, count);
}

// Private Member Functions
BinNode* BinTree::alloc(string itemToAdd) {
	BinNode *myNode = new BinNode(itemToAdd);
	return myNode;
}

void BinTree::free(BinNode *cursor) {
	// post-order delete
	if(cursor != NULL) {
		free(cursor->left);
		free(cursor->right);
		delete cursor;
	}
}

void BinTree::printInOrder(BinNode *cursor, int &count) {
	if(cursor != NULL) {
		printInOrder(cursor->left, count);

		cout << left << setw(0);
		cout << ++count << ". ";
		cout << left << setw(12);
		cout << cursor->data;

		if(debug)
			cout << left << setw(12) << cursor;
		cout << endl;

		printInOrder(cursor->right, count);
	}
}

void BinTree::writeFile(BinNode *cursor, ofstream &outFile) {
	// pre-order
	if(cursor != NULL) {
		outFile << cursor->data << endl;
		writeFile(cursor->left, outFile);
		writeFile(cursor->right, outFile);
	}
}

void BinTree::copyTree(BinNode *cursor) {
	// pre-order
	if(cursor != NULL) {
		addItem(cursor->data);
		copyTree(cursor->left);
		copyTree(cursor->right);
	}
}

void BinTree::inOrderTraverse(BinNode *cursor, void process(int, string&), int &count) {
	if(cursor != NULL) {
		inOrderTraverse(cursor->left, process, count);
		count++;
		process(count, cursor->data);
		inOrderTraverse(cursor->right, process, count);
	}
}