/*
Ryan Lockman
BinNode.h class prototypes.
*/

#ifndef BINNODE_H
#define BINNODE_H

// Headers
#include <string>
using namespace std;

class BinNode {
public:
	// Constructors
	BinNode();
	BinNode(string dataIn);

	// Public Data Members
	string   data;
	BinNode *left;
	BinNode *right;
};

#endif