/*
Ryan Lockman
BinTree.h class prototypes.
*/

#ifndef BINTREE_H
#define BINTREE_H

// Headers
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;
#include "BinNode.h"

class BinTree {
public:
	// Default Constructor
	BinTree();

	// Copy Constructor
	BinTree(const BinTree &source);

	// Destructor
	~BinTree();

	// Assignment Operator
	BinTree& operator=(const BinTree &source);

	// Get Member Functions
	int getUsed() const { return used; }

	// Other Member Functions
	void addItem(string itemToAdd);
	void printAll();
	void readFile(string fileName);
	void writeFile(string fileName);
	void inOrderTraverse(void process(int, string&));

	void debugOn()  {debug = true; }
	void debugOff() {debug = false; }

private:
	// Data Members
	BinNode *root;
	int      used;
	bool     debug;

	// Private Member Functions
	BinNode* alloc      (string itemToAdd);
	void free           (BinNode *cursor);
	void printInOrder   (BinNode *cursor, int &count);
	void writeFile      (BinNode *cursor, ofstream &outFile);
	void copyTree       (BinNode *cursor);
	void inOrderTraverse(BinNode *cursor, void process(int, string&), int &count);
};

#endif