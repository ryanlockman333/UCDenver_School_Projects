/*
Ryan Lockman
BinNode.cpp class definitions.
*/

// Headers
#include "BinNode.h"

// Constructors
BinNode::BinNode() {
	left  = NULL;
	right = NULL;
}

BinNode::BinNode(string dataIn) {
	left  = NULL;
	right = NULL;
	data  = dataIn;
}