/*
Ryan Lockman
CSC 161-001
Project: BinTest
Description: Creates a binaray tree to hold data in a non linear data structure;
*/

// Headers
#include <cctype>
#include "BinTree.h"

// Function Prototypes
void printFormat(int count, string& data);

int main() {
	// Declarations
	BinTree tree;

	tree.debugOn();
	tree.addItem("Julie");
	tree.addItem("Andrew");
	tree.addItem("Chris");
	tree.addItem("Gina");
	tree.addItem("Robert");
	tree.addItem("Nick");
	tree.inOrderTraverse(printFormat);
	tree.printAll();

	BinTree tree2(tree);
	tree2.debugOn();
	tree2.printAll();

	BinTree tree3;
	tree3.debugOn();
	tree3.addItem("NOTHING");
	tree3 = tree2;
	tree3.printAll();

	cin.get();
	return 0;
}

void printFormat(int count, string& data) {
	for(int i = 0; i < data.length(); i++)
		data[i] = toupper(data[i]);

	cout << count << ". " << data << endl;
}