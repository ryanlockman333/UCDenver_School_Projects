/*
Ryan Lockman
CSC 160-001
Project: Primes
Description: Review csc160, variables, arrays, functions, and more.
*/

// Headers
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
using namespace std;
#include "MyFuncts.h"

int main()
{
	// Declarations
	bool     primeNums[1001];
	int      min = 0, max = 0, nthPrime = 0, num = 0;
	string   primeStr, str, numStr;
	ifstream inFile;
	ofstream outFile;

	// Process primeNums Array
	primeNums[0] = false;
	primeNums[1] = false;

	for(int i = 2; i < 1001; i++)
		primeNums[i] = true;

	for(int i = 2; i < 1001; i++)
	{
		if(primeNums[i])
		{
			for(int j = i + 1; j < 1001; j++)
			{
				if(j % i == 0)
					primeNums[j] = false;
			}
		}
	}

	// Open File
	outFile.open("primes.dat");

	// Error Open File
	if(!outFile)
	{
		cout << "Error opening file for writing.\n";
		system("pause");
		return 1;
	}

	// Output To File
	for(int i = 0; i < 1001; i++)
		if(primeNums[i])
			outFile << i << '\t';

	outFile << '\n';

	// Close File
	outFile.close();

	// Input Min/Max
	do
	{
		cout << "Enter MIN value: ";
		cin  >> min;
	}while(!rangeNumValidator(min));

	do
	{
		cout << "Enter MAX value: ";
		cin  >> max;
	}while(!rangeNumValidator(max));

	// Output Primes
	cout << "Prime Values between "	<< min << " & " << max << "\n\n";

	for(int i = min; i <= max; i++)
	{
		if(primeNums[i])
			cout << i << '\t';
	}

	cout << "\n\nEnter the nth prime to find: ";
	cin  >> nthPrime;

	// Open File
	inFile.open("Primes.dat");

	// Error Open File
	if(!inFile)
	{
		cout << "Error opening file.";
		system("pause");
		return 2;
	}

	// Get File
	for( int i = 0; i <= nthPrime; i++)
	{
		getline(inFile, primeStr, '\t');
	}

	// Close File
	inFile.close();

	// Output nth Prime
	cout << '\n' << nthPrime << "nth Prime is: " << primeStr << endl;

	// Declare StringStream
	stringstream ss;
	ss << nthPrime;
	ss >> str;
	str += "nthPrime is : " + primeStr;

	numStr = "10";
	num = atoi(numStr.c_str());

	cout << endl;
	system("pause");
	return 0;
}