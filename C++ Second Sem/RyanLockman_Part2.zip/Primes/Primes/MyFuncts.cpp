/*
Ryan Lockman
MyFuncts.cpp
Stand-alone function implementation definitions.
*/

// Headers
#include "MyFuncts.h"

// Function Definitions
bool rangeNumValidator(int inputNum)
{
	bool ans = false;

	if(inputNum >= 0 && inputNum <= 1000)
		ans = true;

	return(ans);
}