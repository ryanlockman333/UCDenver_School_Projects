/*
Ryan Lockman
MyFuncts.h
Stand-alone function prototypes.
*/

#ifndef MYFUNCTS_H
#define MYFUNCTS_H

// Function Prototypes
bool rangeNumValidator(int inputNum);

#endif