/*
Ryan Lockman
CSC 160-001
Project: Primes
Description: Review csc160, variables, arrays, functions, and more.
*/

// Headers
#include <iostream>
using namespace std;


int main()
{
	// Declarations
	int min = 0, max = 0;

	// Output
	cout << "Enter MIN value: ";
	cin  >> min;
	cout << "Enter MAX value: ";
	cin  >> max;

	cin.ignore();
	cin.get();
	return 0;
}