/*
Ryan Lockman
addrbook.h
Description: Address book collection class prototypes.
*/

// Headers
#include <iostream>
#include <fstream>
#include "addrbook.h"

// Constructors
AddrBook::AddrBook() { used = 0; }

// Set Member Functions
void AddrBook::AddContact(Contact contactIn) {
	if(used < MAX)
		ContactBook[used++] = contactIn;
	else
		cout << "\nContact Book Full\n";
}

void AddrBook::RemoveContact(int index) {
	index--;
	if(index >= 0 && index < used) {
		ContactBook[index] = ContactBook[--used];
		cout << "\nContact Has Been Removed\n";
	}
	else
		cout << "\nCan't Find Contact\n";
}

// Get Member Functions
int AddrBook::GetUsed() const { return used; }

// Other Member Functions
void AddrBook::PrintAddrBook() {
	cout << endl;
	for(int i = 0; i < used; i++)
		cout << (i+1) << ". " << ContactBook[i].ContactToString() << endl;
	cout << endl;
}

void AddrBook::PrintContNumber() {
	cout << "\nNumber of Contacts: " << GetUsed() << "\n";
}

void AddrBook::ReadAddrBook(string fileName) {
	Contact  tmpContact;
	string   line;

	ifstream inFile(fileName);
	if(!inFile) {
		cout << "\nError opening file for reading\n";
		return;
	}

	while(inFile.good()) {
		getline(inFile, line, ',');
		tmpContact.SetFirstName(line);

		getline(inFile, line, ',');
		tmpContact.SetLastName(line);

		getline(inFile, line, ',');
		tmpContact.SetStreet(line);

		getline(inFile, line, ',');
		tmpContact.SetCity(line);

		getline(inFile, line, ',');
		tmpContact.SetState(line);

		getline(inFile, line, ',');
		tmpContact.SetZip(line);

		getline(inFile, line, ',');
		tmpContact.SetPhone(line);

		getline(inFile, line, ',');
		tmpContact.SetEmail(line);

		getline(inFile, line, ',');
		tmpContact.SetBirthday(line);

		getline(inFile, line);
		tmpContact.SetPicture(line);

		AddContact(tmpContact);
	}
	inFile.close();
}

void AddrBook::WriteToAddrBook(string fileName) {
	ofstream outFile(fileName);
	if(!outFile) {
		cout << "\nError opening file for writing\n";
		return;
	}

	for(int i = 0; i < used; i++) {
		if(i == used-1)
			outFile << ContactBook[i].ContactToFileString();
		else
			outFile << ContactBook[i].ContactToFileString() << endl;

	}
	outFile.close();
}