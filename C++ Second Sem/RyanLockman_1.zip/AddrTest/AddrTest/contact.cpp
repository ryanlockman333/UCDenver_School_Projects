/*
Ryan Lockman
contact.h
Desription: Contact class prodefinitions.
*/

// Headers
#include "contact.h"

// Constructors
Contact::Contact() {
	phone = "Unknown";
	birth = "Unknown";
	email = "Unknown";
	pic   = "Unknown";
}

Contact::Contact(string phoneIn, string birthIn, string emailIn, string picIn) {
	phone = phoneIn;
	birth = birthIn;
	email = emailIn;
	pic   = picIn;
}

// Set Member Fuctions
void Contact::SetPhone   (string phoneIn) { phone = phoneIn; }
void Contact::SetBirthday(string birthIn) { birth = birthIn; }
void Contact::SetEmail   (string emailIn) { email = emailIn; }
void Contact::SetPicture (string picIn)   { pic   = picIn; }

// Get Member Functions
string Contact::GetPhone()	  const { return phone; }
string Contact::GetBirthday() const { return birth; }
string Contact::GetEmail()    const { return email; }
string Contact::GetPicture()  const { return pic; }

// Other Member Functions
string Contact::ContactToString() {
	string strContact = ("\n" + NameToString() + "\n" + AddrToString() + "\n" + GetPhone() +
						 "\n" + GetBirthday() + "\n" + GetEmail() + "\n" + GetPicture() + "\n");
	return strContact;
}

string Contact::ContactToFileString() {
	string strContact = (NameToFileString() + AddrToFileString() + GetPhone() + ','
						 + GetBirthday() + ',' + GetEmail() + ',' + GetPicture());
	return strContact;
}