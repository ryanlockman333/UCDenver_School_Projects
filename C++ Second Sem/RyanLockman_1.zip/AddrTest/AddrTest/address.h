/*
Ryan Lockman
address.h
Description: Address class prototypes.
*/

#ifndef ADDRESS_H
#define ADDRESS_H

// Headers
#include <string>
using namespace std;

class Address
{
public:
	// Constructors
	Address();
	Address(string streetIn, string cityIn, string stateIn, string zipIn);

	// Set Member Functions
	void SetStreet(string streetIn);
	void SetCity  (string cityIn);
	void SetState (string stateIn);
	void SetZip   (string zipIn);

	// Get Member Functions
	string GetStreet() const;
	string GetCity()   const;
	string GetState()  const;
	string GetZip()    const;

	// Other Member Functions
	string AddrToString();
	string AddrToFileString();
	
private:
	// Data Members
	string street, city, state, zip;
};

#endif