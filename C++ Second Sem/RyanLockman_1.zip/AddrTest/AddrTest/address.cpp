/*
Ryan Lockman
address.cpp
Description: Address class prototypes.
*/

// Headers
#include "address.h"

// Constructors
Address::Address()
{
	street = "Unknown";
	city   = "Unknown";
	state  = "Unknown";
	zip    = "Unknown";
}

Address::Address(string streetIn, string cityIn, string stateIn, string zipIn) {
	street = streetIn;
	city   = cityIn;
	state  = stateIn;
	zip    = zipIn;
}

// Set Member Functions
void Address::SetStreet(string streetIn) { street = streetIn; }
void Address::SetCity  (string cityIn)	 { city   = cityIn; }
void Address::SetState (string stateIn)  { state  = stateIn; }
void Address::SetZip   (string zipIn)    { zip    = zipIn; }

// Get Member Functions
string Address::GetStreet() const { return street; }
string Address::GetCity()   const { return city; }
string Address::GetState()  const { return state; }
string Address::GetZip()    const { return zip; }

// Other Member Functions
string Address::AddrToString() {
	string strAddress = (street + "\n" + city + ", " + state + " " + zip);
	return strAddress;
}

string Address::AddrToFileString() {
	string strAddress = (street + "," + city + "," + state + "," + zip + ",");
	return strAddress;
}