/*
Ryan Lockman
CSC 160-001
Project: Addrtest.cpp
Description: Address book to store contacts.
*/

// Headers
#include <iostream>
#include "addrbook.h"

int main()
{
	// Declarations
	AddrBook Book;
	Contact  Contact;
	int      choice = 0;
	int      remove;
	string   firstName, lastName;
	string   street, city, state, zip;
	string   phoneNumber, birthday, email;
	string   picture;

	Book.ReadAddrBook("addrbook.csv");
	
	do
	{
		cout << "\n<<<<<<<<<<Address Book>>>>>>>>>>\n\n"
			 << "1. Add New Contact\n"
			 << "2. Find Out Number of Contacts\n"
			 << "3. Print All Contacts\n"
			 <<	"4. Delete a Contact\n"
		     << "5. Exit and Save Program\n\n"
			 << "Please make a choice: ";
		cin  >> choice;

		// Process Choice
		switch(choice) {
			case 1:
				cout << "\nPlease enter First name:     ";
				cin  >> firstName;
				cout << "Please enter Last name:      ";
				cin  >> lastName;

				cin.ignore();
				cout << "Please enter Street Address: ";
				getline(cin, street);
				cout << "Please enter City:           ";
				cin  >> city;
				cout << "Please enter State(AB):      ";
				cin  >> state;
				cout << "Please enter Zip Code:       ";
				cin  >> zip;
				cout << "Please enter Phone Number:   ";
				cin  >> phoneNumber;

				cin.ignore();
				cout << "Please enter Birthday:       ";
				getline(cin, birthday);
				cout << "Please enter E-mail Address: ";
				cin  >> email;
				cout << "Please enter Picture:        ";
				cin  >> picture;
					
				// Input Contact Data
				Contact.SetFirstName(firstName);
				Contact.SetLastName(lastName);
				Contact.SetStreet(street);
				Contact.SetCity(city);
				Contact.SetState(state);
				Contact.SetZip(zip);
				Contact.SetPhone(phoneNumber);
				Contact.SetBirthday(birthday);
				Contact.SetEmail(email);
				Contact.SetPicture(picture);
				Book.AddContact(Contact);

				cout << "\nContact Has Been Added\n";
				break;
			case 2:
				Book.PrintContNumber();
				break;
			case 3:
				Book.PrintAddrBook();
				break;
			case 4:
				cout << "\nPlease Enter Contact's Number to Remove: ";
				cin  >> remove;
				Book.RemoveContact(remove);
				break;
			case 5:
				Book.WriteToAddrBook("addrbook.csv");
				cout << "\nGood Bye!";
				break;
		}
	}while(choice != 5);

	return 0;
}