/*
Ryan Lockman
addrbook.h
Description: Address book collection class prototypes.
*/

#ifndef ADDRBOOK_H
#define ADDRBOOK_H

// Headers
#include "contact.h"

// Defined Constants
#define MAX 10

class AddrBook : public Contact
{
public:
	// Constructors
	AddrBook();

	// Set Member Functions
	void AddContact   (Contact contactIn);
	void RemoveContact(int     index);

	// Get Member Functions
	int  GetUsed() const;

	// Other Member Functions
	void ReadAddrBook   (string fileName);
	void WriteToAddrBook(string fileName);
	void PrintAddrBook();
	void PrintContNumber();
private:
	// Private Data Members
	Contact ContactBook[10];
	int	    used;
};

#endif