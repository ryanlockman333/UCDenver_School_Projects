/*
Ryan Lockman
name.h
Description: Name class definitions.
*/

// Headers
#include "name.h"

// Constructors
Name::Name() {
	firstName = "Unknown";
	lastName  = "Unknown";
}

Name::Name(string fNameIn, string lNameIn) {
	firstName = fNameIn;
	lastName  = lNameIn;
}

// Set Member Functions
void Name::SetFirstName(string fNameIn) { firstName = fNameIn; }
void Name::SetLastName (string lNameIn) { lastName  = lNameIn; }

// Get Member Functions
string Name::GetFirstName() const { return firstName; }
string Name::GetLastName()  const { return lastName; }

// Other Member Functions
string Name::NameToString() {
	string strName = (lastName + ", " + firstName);
	return strName;
}

string Name::NameToFileString() {
	string strName = (firstName + "," + lastName + ",");
	return strName;
}