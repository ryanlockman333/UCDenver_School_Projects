/*
Ryan Lockman
contact.h
Desription: Contact class prototypes.
*/

#ifndef CONTACT_H
#define CONTACT_H

// Headers
#include "name.h"
#include "address.h"

class Contact : public Name, public Address
{
public:
	// Constructors
	Contact();
	Contact(string phoneIn, string birthIn, string emailIn, string picIn);

	// Set Member Fuctions
	void SetPhone   (string phoneIn);
	void SetBirthday(string birthIn);
	void SetEmail   (string emailIn);
	void SetPicture (string picIn);

	// Get Member Functions
	string GetPhone()    const;
	string GetBirthday() const;
	string GetEmail()    const;
	string GetPicture()  const;

	// Other Member Functions
	string ContactToString();
	string ContactToFileString();

private:
	// Data Members
	string  phone, birth, email;
	string  pic;
};

#endif