/*
Ryan Lockman
name.h
Description: Name class prototypes.
*/

#ifndef NAME_H
#define NAME_H

// Headers
#include <string>
using namespace std;

class Name
{
public:
	// Constructors
	Name();
	Name(string fNameIn, string lNameIn);

	// Set Member Functions
	void SetFirstName(string fNameIn);
	void SetLastName (string lNameIn);

	// Get Member Functions
	string GetFirstName() const;
	string GetLastName()  const;

	// Other Member Functions
	string NameToString();
	string NameToFileString();
	
private:
	// Data Members
	string firstName, lastName;
};

#endif