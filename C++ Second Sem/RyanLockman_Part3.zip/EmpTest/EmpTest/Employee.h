/*
Ryan Lockman
Employee.h
Description: Employee class prototypes.
*/

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

// Headers
#include <string>
using namespace std;
#include "Date.h"

class Employee
{
public:
	// Conctructors
	Employee(); // Default
	Employee(string nameIn, double salaryIn);
	Employee(string nameIn, double salaryIn, Date dateIn);

	// Get Member Functions
	string GetName()    const;
	double GetSalary()  const;
	Date GetStartDate() const;

	// Set Member Functions
	void SetName     (string nameIn);
	void SetSalary   (double salaryIn);
	void SetStartDate(Date dateIn);

	// Other Member Functions
	string ToString();
	string ToFileString();

private:
	// Data Members
	string name;
	double salary;
	Date   startDate;

	// Private Member Functions
	string SalaryToString();
};

#endif