/*
Ryan Lockman
CSC 160-001
Project: EmpTest
Description: Employee Test
*/

// Headers
#include <iostream>
#include "Employee.h"

int main()
{
	// Constructors - Create Objects
	Employee me;
	Employee you("Robert", 100000);
	Employee him("Nick", 500000);
	Date     yourStartDate;
	Date     hisStartDate;

	// object.memberFunction();
	me.SetName("Ryan");
	me.SetSalary(25000);

	hisStartDate.SetDate(11, 30, 2012);
	yourStartDate.SetDate("02/06/2013");

	him.SetStartDate(hisStartDate);
	you.SetStartDate(yourStartDate);

	cout << me.ToString()  << endl;
	cout << you.ToString() << endl;
	cout << him.ToString() << endl;

	cin.get();
	return 0;
}
