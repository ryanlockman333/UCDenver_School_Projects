/*
Ryan Lockman
Employee.cpp
Description: Employee class definitions.
*/

// Headers
#include <sstream>
#include "Employee.h"

// Conctructors
Employee::Employee()
{
	name  = "UNKNOWN";
	salary = 0.0;
}

Employee::Employee(string nameIn, double salaryIn)
{
	SetName  (nameIn);
	SetSalary(salaryIn);
}

Employee::Employee(string nameIn, double salaryIn, Date dateIn)
{
	SetName  (nameIn);
	SetSalary(salaryIn);
	startDate = dateIn;
}

// Get Member Functions
string Employee::GetName()      const { return name;       }
double Employee::GetSalary()    const { return salary;     }
Date   Employee::GetStartDate() const { return(startDate); }

// Set Member Functions
void Employee::SetName(string nameIn)
{
	name = nameIn;
}

void Employee::SetSalary(double salaryIn)
{
	if(salaryIn > 0)
		salary = salaryIn;
	else
		salary = 0.0;
}

void Employee::SetStartDate(Date dateIn)
{
	startDate = dateIn;
}

// Other Member Functions
string Employee::ToString() {
	string empStr;

	empStr  = "\nName: " + name + "\nSalary: $" + SalaryToString() + "\n";
	empStr += "Start Date: " + startDate.DateToString() + "\n";

	return empStr;
}

string Employee::ToFileString()
{
	string empStr;

	empStr  = name + "," + SalaryToString() + ",";
	empStr += startDate.DateToFileString();

	return empStr;
}

string Employee::SalaryToString()
{
	string salStr;
	stringstream ss;

	ss << salary;
	ss >> salStr;

	return salStr;
}