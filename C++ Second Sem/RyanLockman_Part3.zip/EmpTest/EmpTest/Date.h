/*
Ryan Lockman
Date.h
Descriotion: Date Class prototypes.
 */

#ifndef DATE_H
#define DATE_H

// Headers
#include <string>
using namespace std;

class Date
{
public:
	// Constructors
	Date();
	Date(int monthIn, int dayIn, int yearIn);
	
	// Get Member Functions
	int GetMonth() const;
	int GetDay()   const;
	int GetYear()  const;

	// Set Member Functions
	void SetMonth(int monthIn);
	void SetDay  (int dayIn);
	void SetYear (int yearIn);
	void SetDate (string monthIn, string dayIn, string yearIn);
	void SetDate (int monthIn, int dayIn, int yearIn);
	void SetDate (string dateIn);        // "mm/dd/yyyy"

	// Other Member Functions
	bool   ValidateMonth(int monthIn);
	bool   ValidateDay  (int dayIn);
	bool   ValidateYear (int yearIn);
	void   ParseDate    (string dateIn); // "mm/dd/yyyy"
	string DateToString();
	string DateToFileString();
private:
	// Data Members
	int month;
	int day;
	int year;

	// Private Member Functions
	string MonthToString();
	string DayToString();
	string YearToString();

};

#endif