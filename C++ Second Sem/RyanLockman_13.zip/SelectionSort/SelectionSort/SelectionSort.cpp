/*
Project: SelectionSort.cpp
Description: Take a list and sort it via a selection algorithm.
*/

// Headers
#include <iostream>
using namespace std;

// Constants
const int MAX = 20;

int main() {
	// Declarations
	int list[MAX]  = {20,19,18,17,16,14,13,12,11,10,9,8,7,6,5,4,3,2,1};
	int smallIndex = 0;
	int temp       = 0;

	cout << "Before sort.\n\n";
	for(int i = 0; i < MAX; i++)
		cout << list[i] << " ";

	// Sort List
	for(int index = 0; index < MAX-1; index++) {                    // index      = [0]4
		smallIndex = index;											// smallIndex = [0]4
		for(int location = index+1; location < MAX; location++)     // location   = [1]3
			if(list[location] < list[smallIndex])					// if lists's location[1]3 is less than lists smallIndex[0]4
				smallIndex = location;                              // smallIndex = [1]3

		temp             = list[smallIndex];
		list[smallIndex] = list[index];
		list[index]      = temp;

	cout << "\n\nAfter round " << index+1 << "\n\n";
	for(int i = 0; i < MAX; i++)
		cout << list[i] << " ";
	}

	cin.get();
	return 0;
}