/*
Ryan Lockman
Date.cpp
Description: Date class definitions.
 */

// Headers
#include <sstream>
#include "Date.h"

// Constructors
Date::Date() {
	month = 1;
	day   = 1;
	year  = 2013;
}

Date::Date(int monthIn, int dayIn, int yearIn) {
	SetDate(monthIn, dayIn, yearIn);
}
	
// Get Member Functions
int Date::GetMonth() const { return month; }
int Date::GetDay()   const { return day;   }
int Date::GetYear()  const { return year;  }

// Set Member Functions
void Date::SetMonth(int monthIn) {
	if(ValidateMonth(monthIn))
		month = monthIn;
	else
		month = 1;
}

void Date::SetDay(int dayIn) {
	if(ValidateDay(dayIn))
		day = dayIn;
	else
		day = 1;
}

void Date::SetYear(int yearIn) {
	if(ValidateYear(yearIn))
		year = yearIn;
	else
		year = 2013;
}

void Date::SetDate(string monthIn, string dayIn, string yearIn) {
	string fullDate = monthIn + "/" + dayIn + "/" + yearIn;

	ParseDate(fullDate);
}

void Date::SetDate(int monthIn, int dayIn, int yearIn) {
	SetMonth(monthIn);
	SetDay  (dayIn);
	SetYear (yearIn);
}

void Date::SetDate(string dateIn) { ParseDate(dateIn); }

// Other Member Functions
bool Date::ValidateMonth(int monthIn) {
	if(monthIn >= 1 && monthIn <= 12)
		return(true);

	return(false);
}

bool Date::ValidateDay(int dayIn) {
	if(dayIn >= 1 && dayIn <= 31)
		return(true);

	return(false);
}

bool Date::ValidateYear(int yearIn) {
	if(yearIn >= 1970 && yearIn <= 2013)
		return(true);

	return(false);
}

void Date::ParseDate(string dateIn) {
	string monthStr, dayStr, yearStr;
	int monthTmp = 0, dayTmp = 0, yearTmp = 0;
	stringstream ss;
	ss << dateIn;
	getline(ss, monthStr, '/');
	getline(ss, dayStr, '/');
	getline(ss, yearStr);

	monthTmp = atoi(monthStr.c_str());
	dayTmp   = atoi(dayStr.c_str());
	yearTmp  = atoi(yearStr.c_str());

	SetDate(monthTmp, dayTmp, yearTmp);
}

string Date::DateToString() {
	string dateStr;

	dateStr = MonthToString() + "/" + DayToString() + "/" + YearToString();

	return dateStr;
}

string Date::DateToFileString() {
	string dateStr;

	dateStr = MonthToString() + "," + DayToString() + "," + YearToString() + ",";

	return dateStr;
}

string Date::MonthToString() {
	string monthStr;
	stringstream ss;

	ss << month;
	ss >> monthStr;

	return monthStr;
}

string Date::DayToString() {
	string dayStr;
	stringstream ss;

	ss << day;
	ss >> dayStr;

	return dayStr;
}

string Date::YearToString() {
	string yearStr;
	stringstream ss;

	ss << year;
	ss >> yearStr;

	return yearStr;
}