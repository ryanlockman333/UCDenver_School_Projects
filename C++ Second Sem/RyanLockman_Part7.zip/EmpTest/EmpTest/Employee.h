/*
Ryan Lockman
Employee.h
Description: Employee class prototypes.
*/

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

// Headers
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
#include "Date.h"
#include "Field.h"

class Employee {
public:
	// Conctructors
	Employee(); // Default
	Employee(string nameIn, double salaryIn);
	Employee(string nameIn, double salaryIn, Date dateIn);

	// Get Member Functions
	string GetName()    const;
	double GetSalary()  const;
	Date GetStartDate() const;

	// Set Member Functions
	void SetName(string nameIn);
	void SetSalary(double salaryIn);
	void SetStartDate(Date dateIn);

	// Other Member Functions
	string ToString();
	string ToFileString();

	/*bool operator==(const Employee &e2);*/ // Have to have all relational operators the same, otherwise you'll get an error(so all friends, or all member functions, or all stand-alone functions)

	// Relation Operators
	friend bool operator==(const Employee &e1, const Employee &e2);
	friend bool operator!=(const Employee &e1, const Employee &e2);
	friend bool operator<(const Employee &e1, const Employee &e2);
	friend bool operator>=(const Employee &e1, const Employee &e2);
	friend bool operator>(const Employee &e1, const Employee &e2);
	friend bool operator<=(const Employee &e1, const Employee &e2);

	// Stream Operators
	friend istream& operator>>(istream &is, Employee &emp);
	friend ifstream& operator>>(ifstream &ifs, Employee &emp);
	friend ostream& operator<<(ostream &os, const Employee &emp);
	friend ofstream& operator<<(ofstream &ofs, const Employee &emp);

private:
	// Data Members
	Field  name;
	double salary;
	Date   startDate;

	// Private Member Functions
	string SalaryToString();
};

#endif