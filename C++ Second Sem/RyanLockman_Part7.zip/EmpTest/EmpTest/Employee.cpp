/*
Ryan Lockman
Employee.cpp
Description: Employee class definitions.
*/

// Headers
#include <sstream>
#include "Employee.h"

// Conctructors
Employee::Employee() {
	name   = "UNKNOWN";
	salary = 0.0;
}

Employee::Employee(string nameIn, double salaryIn) {
	SetName(nameIn);
	SetSalary(salaryIn);
}

Employee::Employee(string nameIn, double salaryIn, Date dateIn) {
	SetName(nameIn);
	SetSalary(salaryIn);
	startDate = dateIn;
}

// Get Member Functions
string Employee::GetName()      const { return name; }
double Employee::GetSalary()    const { return salary; }
Date   Employee::GetStartDate() const { return startDate; }

// Set Member Functions
void Employee::SetName(string nameIn) { name = nameIn; }

void Employee::SetSalary(double salaryIn) {
	if(salaryIn > 0)
		salary = salaryIn;
	else
		salary = 0.0;
}

void Employee::SetStartDate(Date dateIn) { startDate = dateIn; }

// Other Member Functions
string Employee::ToString() {
	string empStr;

	empStr  = "\nName: " + name + "\nSalary: $" + SalaryToString() + "\n";
	empStr += "Start Date: " + startDate.DateToString() + "\n";

	return empStr;
}

string Employee::ToFileString() {
	string empStr;

	empStr  = name + "," + SalaryToString() + ",";
	empStr += startDate.DateToFileString();

	return empStr;
}

string Employee::SalaryToString() {
	string salStr;
	stringstream ss;

	ss << salary;
	ss >> salStr;

	return salStr;
}

// Relational Operators
/*bool Employee::operator==(const Employee &e2) {
	if(name == e2.name && salary == e2.salary)
		return true;
	return false;
}*/

bool operator==(const Employee &e1, const Employee &e2) {
	if(e1.name == e2.name && e1.salary == e2.salary)
		return true;
	return false;
}

bool operator!=(const Employee &e1, const Employee &e2) {
	return(!(e1 == e2));
}

bool operator<(const Employee &e1, const Employee &e2) {
	return(e1.salary < e2.salary);
}

bool operator>=(const Employee &e1, const Employee &e2) {
	return(!(e1 < e2));
}

bool operator>(const Employee &e1, const Employee &e2) {
	return(e1.salary > e2.salary);
}

bool operator<=(const Employee &e1, const Employee &e2) {
	return(!(e1 > e2));
}

// Stream Operators
istream& operator>>(istream &is, Employee &emp) {
	cout << "Enter your name: ";
	is >> emp.name;
	cout << "Enter your slaary: ";
	is >> emp.salary;
	return is;
}

ifstream& operator>>(ifstream &ifs, Employee &emp) {
	ifs >> emp.name;
	return ifs;
}

ostream& operator<<(ostream &os, const Employee &emp) {
	os << emp.GetName() << "\t$" << emp.GetSalary();
	return os;
}

ofstream& operator<<(ofstream &ofs, const Employee &emp) {
	ofs << emp.name << "," << emp.salary << ",";
	return ofs;
}