/*
Ryan Lockman
CSC 160-001
Project: EmpTest
Description: Employee Test
*/

// Headers
#include <iostream>
#include "Employee.h"

int main() {
	// Constructors - Create Objects
	Employee me;
	Employee you("Robert", 100000);
	Employee him("Nick", 500000);
	Date     yourStartDate;
	Date     hisStartDate;

	// object.memberFunction();
	cin >> me;

	hisStartDate.SetDate(11, 30, 2012);
	yourStartDate.SetDate("02/06/2013");

	him.SetStartDate(hisStartDate);
	you.SetStartDate(yourStartDate);

	cout << me  << endl;

	cout << you.ToString() << endl;
	cout << him.ToString() << endl;

	if(me < you)
		cout << "Smallest: " << me << endl;

	cin.ignore();
	cin.get();
	return 0;
}
