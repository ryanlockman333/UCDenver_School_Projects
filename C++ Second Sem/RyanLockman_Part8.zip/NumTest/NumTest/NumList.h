/*
Ryan Lockman
NumList.h class declarations.
*/

#ifndef NUMLIST_H
#define NUMLIST_H

// Headers
#include <iostream>
#include <cstdlib>
#include <string>
#include <algorithm>
using namespace std;

template <class Type>
class NumList {
public:
	// Default Constructor
	NumList();

	// Copy Constructor
	NumList(const NumList<Type> &source);

	// Assignment Operator
	NumList<Type>& operator=(const NumList<Type> &source);

	// Destructor
	~NumList();

	// Get Member Functions
	int  getUsed() const { return used; }
	int  getMax()  const { return max; }
	Type getItem(int index);

	// Other Member Functions
	void addItem        (Type itemToAdd);
	void removeItem     (Type itemToRemove);
	void removeAt       (int indexToRemove); 
	int  findIndexOfItem(Type itemToFind);
	void readFile       (string fileName);
	void writeFile      (string fileName);
	void print();

	void debugOn()  { debug = true; }
	void debugOff() { debug = false; }

private:
	// Data Members
	bool  debug;
	Type *ptr;
	int   used;
	int   max;

	// Private Member Functions
	void alloc(int sizeIncrease);
	void free();
};

#include "numlist.tem"

#endif