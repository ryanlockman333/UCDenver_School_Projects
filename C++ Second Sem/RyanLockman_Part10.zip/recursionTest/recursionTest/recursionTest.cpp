/*
Ryan Lockman
CSC 260-001
Project: RecursionTest
Description: A function that calls itself.
*/

// Hearders
#include <iostream>

// Function Prototypes
int    factorial  (int i);
double combination(double n, double r, double n_r);
int    guessNum   (int first, int last, int &count);
void   stars      (int n);

int main() {
	// Declarations
	int    answer = 1, count = 0;
	double combo  = 0;

	answer = factorial(5);
	combo  = combination(5, 3, 2);

	/*for(int i = 5; i >= 1; i--)
		answer *= i; // same as factorial prototype*/

	std::cout << "Factorial: "       << answer << "\n\n";
	std::cout << "Combination 5C3: " << combo  << "\n\n";

	std::cout << "\n\nGuess a # between (1-100):\n";

	if(guessNum(1, 100, count) == -1)
		std::cout << "You didn't guess a # in the range\n\n";
	else
		std::cout << "I guessed your # in " << count << " tries\n\n";

	stars(12);

	std::cin.ignore();
	std::cin.get();
	return 0;
}

int factorial(int i) {
	int answer = 1;

	if(i == 1)
		return 1; // stoping case

	answer = i * factorial(i-1);
	return answer;
}

double combination(double n, double r, double n_r) {
	double answer = 1;

	if(n == 1)
		return 1; // stoping case
	if(r < 1)
		r = 1;
	if(n_r < 1)
		n_r = 1;

	answer = n / (r * n_r) * combination(n-1, r-1, n_r-1);
	return answer;
}

int guessNum(int first, int last, int &count) {
	char ans = 0;
	int  mid = (first+last)/2;

	count++;

	std::cout << "Is your #: " << mid << "? ";
	std::cin  >> ans;

	if(ans == 'y' || ans == 'Y')
		return mid;  // stoping case
	if(first > last)
		return -1;   // stoping case

	std::cout << "Is your # less than " << mid << "? ";
	std::cin  >> ans;

	if(ans == 'y' || ans == 'Y')
		return( guessNum(first, mid-1, count) );
	else
		return( guessNum(mid+1, last, count) );

}

void stars(int n) {
	if(n == 0)
		return; // stoping case

	std::cout << "*";
	stars(n-1);
}