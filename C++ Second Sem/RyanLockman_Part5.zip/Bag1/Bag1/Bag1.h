/*
Ryan Lockman
Bag.h
Description: Bag class prototypes.
*/

#ifndef BAG1_H
#define BAG1_H

// Headers
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Defined Constants
#define MAX 5

class Bag
{
public:
	// Constructors
	Bag(); // Default

	// Set Member Functions
	/*None*/

	// Get Member Functions
	int    GetUsed() const;
	double GetItem(int index) const;

	// Other Member Functions
	void AddItem(double itemToAdd);
	void RemoveItem(double itemToRemove);
	void RemoveItemAtIndex(int index);
	int  FindItem(double itemToFind);
	void PrintAllItems();
	void ReadFile(string fileName);
	void WriteFile(string fileName);

private:
	// Data Members
	double nums[MAX];
	int    used;

};

#endif