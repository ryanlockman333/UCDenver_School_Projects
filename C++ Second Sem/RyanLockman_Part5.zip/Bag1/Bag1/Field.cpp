/*
Ryan Lockman
Field.h
Description: Field class definitions.
*/

// Headers
#include "Field.h"

// Constructors
Field::Field() : string() // calling default string
{}

Field::Field(const char* chrStr) : string(chrStr)
{}

Field:: Field(string str) : string(str) // copy constructor
{}

// Filed fld;
// ifstream inFile;
// inFile >> fld;
/* This above executes the below.*/

ifstream& operator>>(ifstream& is, Field& fld) {
	getline(is, fld, ',');
	return is;
}

istream& operator>>(istream& is, Field& fld) {
	if(is.peek() == '\n')
		is.ignore();

	getline(is, fld, '\n');
	return is;
}