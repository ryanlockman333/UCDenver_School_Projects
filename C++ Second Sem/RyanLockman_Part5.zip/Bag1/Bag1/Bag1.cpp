/*
Ryan Lockman
Bag.cpp
Description: Bag class definitions.
*/

// Headers
#include "Bag1.h"

// Constructors
Bag::Bag() { used = 0; }

// Set Member Functions
/*None*/

// Get Member Functions
int Bag::GetUsed() const { 
	return used;
}

double Bag::GetItem(int index) const {
	double tmp = 0.0;

	if(index >= 0 && index < used)
		tmp = nums[index];

	return tmp;
}

// Other Member Functions
void Bag::AddItem(double itemToAdd) {
	if(used < MAX)
		nums[used++] = itemToAdd;

	/*
	above is shortcut
	nums[used] = itemToAdd;
	used++
	*/
}

void Bag::RemoveItem(double itemToRemove) {
	int index = FindItem(itemToRemove);

	if(index >= 0)
		RemoveItemAtIndex(index);
}

void Bag::RemoveItemAtIndex(int index) {
	if(index >= 0 && index < used)
		nums[index] = nums[--used];

	/*
	above is shortcut
	--used;
	nums[index] = nums[used];
	*/
}

int Bag::FindItem(double itemToFind) {
	int indexFound = -1;

	for(int i = 0; i < used; i++)
		if(nums[i] == itemToFind) {
			indexFound = i;
			break;
		}

	return indexFound;
}

void Bag::PrintAllItems() {
	cout << "\n\nThe Items\n";
	for(int i = 0; i < used; i++)
		cout << (i+1) << ". " << nums[i] << endl;
	cout << "\n";
}

void Bag::ReadFile(string fileName) {
	double   tmp = 0.0;
	ifstream inFile(fileName.c_str());

	if(!inFile) {
		cout << "Error opening file for reading\n";
		return;
	}

	// Read All Data From File
	inFile >> tmp;
	while(!inFile.fail()) {
		AddItem(tmp);

		inFile >> tmp;
	}

	inFile.close();
}

void Bag::WriteFile(string fileName) {
	ofstream outFile(fileName.c_str());

	if(!outFile) {
		cout << "Error opening file for writing\n";
		return;
	}


	 // Write Data To File
	for(int i = 0; i < used; i++)
		outFile << nums[i] << endl;

	outFile.close();
}