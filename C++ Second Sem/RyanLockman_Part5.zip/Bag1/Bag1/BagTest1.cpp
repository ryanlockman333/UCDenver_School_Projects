/*
Ryan Lockman
CSC 160-001
Project: BagTest
Description: Using a Bag Class to store numbers.
*/

// Headers
#include "Bag1.h"

int main()
{
	// Declarations
	Bag Primes;

	Primes.ReadFile("primes.dat");

	cout << "After Read File\n";
	Primes.PrintAllItems();

	Primes.AddItem(2.0);
	Primes.AddItem(3.0);
	Primes.AddItem(5.0);

	Primes.PrintAllItems();

	Primes.AddItem(7.0);
	Primes.AddItem(11.0);
	Primes.AddItem(13.0);

	Primes.PrintAllItems();

	Primes.RemoveItemAtIndex(0);

	Primes.RemoveItem(7.0);

	Primes.PrintAllItems();

	Primes.WriteFile("primes.dat");

	cin.get();
	return 0;
}