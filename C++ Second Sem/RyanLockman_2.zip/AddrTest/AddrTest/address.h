/*
Ryan Lockman
address.h
Description: Address class prototypes.
*/

#ifndef ADDRESS_H
#define ADDRESS_H

// Headers
#include <string>
using namespace std;
#include "field.h"

namespace AddressInfo {

class Address {
public:
	// Constructors
	Address();
	Address(Field streetIn, Field cityIn, Field stateIn, Field zipIn);

	// Set Member Functions
	void SetStreet(Field streetIn) { street = streetIn; }
	void SetCity  (Field cityIn)   { city   = cityIn; }
	void SetState (Field stateIn)  { state  = stateIn; }
	void SetZip   (Field zipIn)    { zip    = zipIn; }

	// Get Member Functions
	Field GetStreet() const { return street; }
	Field GetCity()   const { return city; }
	Field GetState()  const { return state; }
	Field GetZip()    const { return zip; }

	// Other Member Functions
	Field AddrToString();
	Field AddrToFileString();
	
private:
	// Data Members
	Field street, city, state, zip;
};

}

#endif