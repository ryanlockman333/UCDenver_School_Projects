/*
Ryan Lockman
name.h
Description: Name class prototypes.
*/

#ifndef NAME_H
#define NAME_H

// Headers
#include <string>
using namespace std;
#include "field.h"

namespace AddressInfo {

class Name {
public:
	// Constructors
	Name();
	Name(Field fNameIn, Field lNameIn);

	// Set Member Functions
	void SetFirstName(Field fNameIn) { firstName = fNameIn; }
	void SetLastName (Field lNameIn) { lastName  = lNameIn; }

	// Get Member Functions
	Field GetFirstName() const { return firstName; }
	Field GetLastName()  const { return lastName; }

	// Other Member Functions
	Field NameToString();
	Field NameToFileString();
	
private:
	// Data Members
	Field firstName, lastName;
};

}

#endif