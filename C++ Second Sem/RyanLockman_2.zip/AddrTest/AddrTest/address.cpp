/*
Ryan Lockman
address.cpp
Description: Address class prototypes.
*/

// Headers
#include "address.h"
using namespace AddressInfo;

// Constructors
Address::Address() {
	street = "Unknown";
	city   = "Unknown";
	state  = "Unknown";
	zip    = "Unknown";
}

Address::Address(Field streetIn, Field cityIn, Field stateIn, Field zipIn) {
	street = streetIn;
	city   = cityIn;
	state  = stateIn;
	zip    = zipIn;
}

// Other Member Functions
Field Address::AddrToString() {
	string strAddress = (GetStreet()+ "\n" + GetCity() + ", " + GetState() + " " + GetZip() + "\n");
	return strAddress;
}

Field Address::AddrToFileString() {
	string strAddress = (GetStreet() + "," + GetCity() + "," + GetState() + "," + GetZip() + ",");
	return strAddress;
}