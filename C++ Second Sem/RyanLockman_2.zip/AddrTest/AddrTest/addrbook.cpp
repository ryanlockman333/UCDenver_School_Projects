/*
Ryan Lockman
addrbook.h
Description: Address book collection class prototypes.
*/

// Headers
#include <iostream>
#include <fstream>
#include "addrbook.h"
using namespace AddressInfo;

// Set Member Functions
void AddrBook::AddContact(CategorizedContact contactIn) {
	if(used < MAX)
		ContactBook[used++] = contactIn;
	else
		cout << "\nContact Book Full\n";
}

void AddrBook::RemoveContact(int index) {
	index--;
	if(index >= 0 && index < used) {
		ContactBook[index] = ContactBook[--used];
		cout << "\nContact Has Been Removed\n";
	}
	else
		cout << "\nCan't Find Contact\n";
}

// Other Member Functions
void AddrBook::PrintCategorizedAddrBook(Field categoryIn) {
	if(categoryIn == "1")
		categoryIn = "Business";
	else if(categoryIn == "2")
		categoryIn = "Colleague";
	else if(categoryIn == "3")
		categoryIn = "Family";
	else if(categoryIn == "4")
		categoryIn = "Friend";
	else if(categoryIn == "5")
		categoryIn = "School";
	
	if(categoryIn == "6") {
		cout << endl;
		for(int i = 0; i < used; i++)
			cout << (i+1) << ". " << ContactBook[i].CategoryToString() << endl;
		cout << endl;
	}
	else {
		cout << endl;
		for(int i = 0; i < used; i++)
			if(ContactBook[i].GetCategory() == categoryIn)
				cout << (i+1) << ". " << ContactBook[i].CategoryToString() << endl;
		cout << endl;
	}
}

void AddrBook::PrintContNumber() {
	cout << "\nNumber of Contacts: " << GetUsed() << "\n";
}

void AddrBook::ReadAddrBook(Field fileName) {
	CategorizedContact TmpCatContact;
	Field fld;

	ifstream inFile(fileName);
	if(!inFile) {
		cout << "\nError opening file for reading\n";
		return;
	}

	while(inFile.good()) {
		inFile >> fld;
		TmpCatContact.SetCategory(fld);

		inFile >> fld;
		TmpCatContact.SetNameObjFirst(fld);
		inFile >> fld;
		TmpCatContact.SetNameObjLast(fld);

		inFile >> fld;
		TmpCatContact.SetAddrObjStreet(fld);
		inFile >> fld;
		TmpCatContact.SetAddrObjCity(fld);
		inFile >> fld;
		TmpCatContact.SetAddrObjState(fld);
		inFile >> fld;
		TmpCatContact.SetAddrObjZip(fld);

		inFile >> fld;
		TmpCatContact.SetPhone(fld);
		inFile >> fld;
		TmpCatContact.SetEmail(fld);
		inFile >> fld;
		TmpCatContact.SetBirthday(fld);
		inFile >> fld;
		TmpCatContact.SetPicture(fld);

		AddContact(TmpCatContact);
	}
	inFile.close();
}

void AddrBook::WriteToAddrBook(Field fileName) {
	ofstream outFile(fileName);
	if(!outFile) {
		cout << "\nError opening file for writing\n";
		return;
	}

	for(int i = 0; i < used; i++) {
		if(i == used-1)
			outFile << ContactBook[i].CategoryToFileString();
		else
			outFile << ContactBook[i].CategoryToFileString() << endl;
	}
	outFile.close();
}