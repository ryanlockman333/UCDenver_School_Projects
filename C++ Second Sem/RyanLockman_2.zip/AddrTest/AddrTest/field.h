/*
Ryan Lockman
Field.h
Description: Field class prototypes.
*/

#ifndef FIELD_H
#define FIELD_H

// Headers
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class Field: public string {
public:
// Constructors
	// Default Constructor
	Field();

	Field(const char *chrStr);

	// Copy Constructor
	Field(string str);
};

ifstream& operator>>(ifstream &is, Field &fld);
istream&  operator>>(istream &is, Field &fld);

#endif