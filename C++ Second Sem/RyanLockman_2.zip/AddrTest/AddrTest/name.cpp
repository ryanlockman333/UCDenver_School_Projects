/*
Ryan Lockman
name.h
Description: Name class definitions.
*/

// Headers
#include "name.h"
using namespace AddressInfo;

// Constructors
Name::Name() {
	firstName = "Unknown";
	lastName  = "Unknown";
}

Name::Name(Field fNameIn, Field lNameIn) {
	firstName = fNameIn;
	lastName  = lNameIn;
}

// Other Member Functions
Field Name::NameToString() {
	string strName = (GetLastName() + ", " + GetFirstName() + "\n" );
	return strName;
}

Field Name::NameToFileString() {
	string strName = (GetFirstName() + "," + GetLastName() + ",");
	return strName;
}