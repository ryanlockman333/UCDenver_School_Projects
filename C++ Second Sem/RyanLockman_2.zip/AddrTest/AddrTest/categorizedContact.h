/*
Ryan Lockman
categorizedContact.h class prototypes.
*/

// Headers
#include "contact.h"
using namespace AddressInfo;

#ifndef CATEGORIZEDCONTACT_H
#define CATEGORIZEDCONTACT_H

namespace AddressInfo {

class CategorizedContact: public Contact {
public:
	// Constructors
	CategorizedContact()				  { category = "Unknown"; }
	CategorizedContact(string categoryIn) { category = categoryIn; }

	// Set Member Functions

	void SetCategory(Field categoryIn);

	// Get Member Functions
	Field GetCategory() const { return category; }
	
	// Other Member Functions
	Field CategoryToString();
	Field CategoryToFileString();

private:
	// Data Members
	Field category;
};

}

#endif