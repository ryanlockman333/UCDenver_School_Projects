/*
Ryan Lockman
Field.h
Description: Field class definitions.
*/

// Headers
#include "Field.h"

// Default Constructor
Field::Field() : string() { }

Field::Field(const char* chrStr) : string(chrStr) { }

// Copy Constructor
Field::Field(string str) : string(str) { }

ifstream& operator>>(ifstream &is, Field &fld) {
	getline(is, fld, ',');
	if(is.peek() == '\n')
		is.ignore();
	return is;
}

istream& operator>>(istream &is, Field &fld) {
	if(is.peek() == '\n')
		is.ignore();
	getline(is, fld, '\n');
	return is;
}