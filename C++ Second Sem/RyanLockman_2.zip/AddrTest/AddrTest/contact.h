/*
Ryan Lockman
contact.h
Desription: Contact class prototypes.
*/

#ifndef CONTACT_H
#define CONTACT_H

// Headers
#include "name.h"
#include "address.h"

namespace AddressInfo {

class Contact {
public:
	// Constructors
	Contact();
	Contact(Field phoneIn, Field birthIn, Field emailIn, Field picIn);

	// Set Member Fuctions
	void SetPhone   (Field phoneIn) { phone = phoneIn; }
	void SetBirthday(Field birthIn) { birth = birthIn; }
	void SetEmail   (Field emailIn) { email = emailIn; }
	void SetPicture (Field picIn)   { pic   = picIn; }

	void SetNameObjFirst (Field fNameIn)  { NameObj.SetFirstName(fNameIn); }
	void SetNameObjLast  (Field lNameIn)  { NameObj.SetLastName(lNameIn); }
	void SetAddrObjStreet(Field streetIn) { AddrObj.SetStreet(streetIn); }
	void SetAddrObjCity  (Field cityIn)   { AddrObj.SetCity(cityIn); }
	void SetAddrObjState (Field stateIn)  { AddrObj.SetState(stateIn); }
	void SetAddrObjZip   (Field zipIn)    { AddrObj.SetZip(zipIn); }

	// Get Member Functions
	Field  GetPhone()	 const { return phone; }
	Field  GetBirthday() const { return birth; }
	Field  GetEmail()    const { return email; }
	Field  GetPicture()  const { return pic; }
	Name    GetNameObj() const { return NameObj; }
	Address GetAddrObj() const { return AddrObj; }

	// Other Member Functions
	Field ContactToString();
	Field ContactToFileString();

protected:
	// Data Members
	Name    NameObj;
	Address AddrObj;
	Field   phone, birth, email;
	Field   pic;
};

}

#endif