/*
Ryan Lockman
contact.h
Desription: Contact class prodefinitions.
*/

// Headers
#include "contact.h"
using namespace AddressInfo;

// Constructors
Contact::Contact() {
	phone = "Unknown";
	birth = "Unknown";
	email = "Unknown";
	pic   = "Unknown";
}

Contact::Contact(Field phoneIn, Field birthIn, Field emailIn, Field picIn) {
	phone = phoneIn;
	birth = birthIn;
	email = emailIn;
	pic   = picIn;
}

// Other Member Functions
Field Contact::ContactToString() {
	string strContact = (GetPhone() + "\n" + GetBirthday() + "\n"
						 + GetEmail() + "\n" + GetPicture() + "\n");
	return strContact;
}

Field Contact::ContactToFileString() {
	string strContact = (GetPhone() + "," + GetEmail() + ","
						 + GetBirthday() + "," + GetPicture() + ",");
	return strContact;
}