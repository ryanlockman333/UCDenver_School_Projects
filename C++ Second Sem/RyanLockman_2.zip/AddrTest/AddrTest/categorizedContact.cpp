/*
Ryan Lockman
categorizedContact.h class definitions.
*/

// Headers
#include "categorizedContact.h"
using namespace AddressInfo;

// Set Member Functions
void CategorizedContact::SetCategory(Field categoryIn) {
	category = categoryIn;
	if(category == "1")
		category = "Business";
	else if(category == "2")
		category = "Colleague";
	else if(category == "3")
		category = "Family";
	else if(category == "4")
		category = "Friend";
	else if(category == "5")
		category = "School";
}

// Other Member Functions
Field CategorizedContact::CategoryToString() {
	string strCategory = (GetCategory() + "\n" + NameObj.NameToString()
						  + AddrObj.AddrToString() + ContactToString());
	return strCategory;
}

Field CategorizedContact::CategoryToFileString() {
	string strCategory = (GetCategory() + ',' + NameObj.NameToFileString()
		                  + AddrObj.AddrToFileString() + ContactToFileString());
	return strCategory;
}