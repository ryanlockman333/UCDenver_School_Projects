/*
Ryan Lockman
addrbook.h
Description: Address book collection class prototypes.
*/

#ifndef ADDRBOOK_H
#define ADDRBOOK_H

// Headers
#include "CategorizedContact.h"
#include "field.h"

// Defined Constants
#define MAX 10

namespace AddressInfo {

class AddrBook {
public:
	// Constructors
	AddrBook() { used = 0; }

	// Set Member Functions
	void AddContact(CategorizedContact contactIn);
	void RemoveContact(int index);

	// Get Member Functions
	int GetUsed() const { return used; }

	// Other Member Functions
	void PrintCategorizedAddrBook(Field categoryIn);
	void PrintContNumber();
	void ReadAddrBook(Field fileName);
	void WriteToAddrBook(Field fileName);

private:
	// Private Data Members
	CategorizedContact ContactBook[10];
	int	used;
};

}

#endif