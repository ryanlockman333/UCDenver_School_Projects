/*
Ryan Lockman
CSC 160-001
Project: Addrtest.cpp
Description: Address book to store contacts.
*/

// Headers
#include <iostream>
#include "addrbook.h"
using namespace AddressInfo;

int main() {
	// Declarations
	CategorizedContact CatContact;
	AddrBook Book;
	Field    fld;
	int      choice = 0;
	int	     remove = 0;

	Book.ReadAddrBook("addrbook.csv");
	
	do
	{
		cout << "\n<<<<<<<<<<Address Book>>>>>>>>>>\n"
			 << "1. Add New Contact\n"
			 << "2. Find Out Number of Contacts\n"
			 << "3. Print All Contacts\n"
			 <<	"4. Delete a Contact\n"
		     << "5. Exit and Save Program\n\n"
			 << "Please make a choice: ";
		cin  >> choice;

		// Process Choice
		switch(choice) {
			case 1:
				cout << "\n<<<<<<<<<<Contact Category>>>>>>>>>>\n"
					 << "(1) Business\n"
					 << "(2) Colleagues\n"
					 << "(3) Family\n"
					 << "(4) Friends\n"
					 << "(5) School\n\n"
					 << "\nPlease choose Contact's category: ";
				cin  >> fld;
				CatContact.SetCategory(fld);

				cout << "\nPlease enter First name:     ";
				cin  >> fld;
				CatContact.SetNameObjFirst(fld);
				cout << "Please enter Last name:      ";
				cin  >> fld;
				CatContact.SetNameObjLast(fld);

				cout << "Please enter Street Address: ";
				cin  >> fld;
				CatContact.SetAddrObjStreet(fld);
				cout << "Please enter City:           ";
				cin  >> fld;
				CatContact.SetAddrObjCity(fld);
				cout << "Please enter State(AB):      ";
				cin  >> fld;
				CatContact.SetAddrObjState(fld);
				cout << "Please enter Zip Code:       ";
				cin  >> fld;
				CatContact.SetAddrObjZip(fld);

				cout << "Please enter Phone Number:   ";
				cin  >> fld;
				CatContact.SetPhone(fld);
				cout << "Please enter Birthday:       ";
				cin  >> fld;
				CatContact.SetBirthday(fld);
				cout << "Please enter E-mail Address: ";
				cin  >> fld;
				CatContact.SetEmail(fld);
				cout << "Please enter Picture:        ";
				cin  >> fld;
				CatContact.SetPicture(fld);
					
				Book.AddContact(CatContact);

				cout << "\nContact Has Been Added\n";
				break;
			case 2:
				Book.PrintContNumber();
				break;
			case 3:
				cout << "\n<<<<<<<<<<Contact Category>>>>>>>>>>\n"
					 << "(1) Business\n"
					 << "(2) Colleagues\n"
					 << "(3) Family\n"
					 << "(4) Friends\n"
					 << "(5) School\n"
					 << "(6) All Contacts\n\n"
					 << "\nPlease choose Contact's category: ";
				cin  >> fld;

				Book.PrintCategorizedAddrBook(fld);
				break;
			case 4:
				cout << "\nPlease Enter Contact's Number to Remove: ";
				cin  >> remove;
				Book.RemoveContact(remove);
				break;
			case 5:
				Book.WriteToAddrBook("addrbook.csv");
				cout << "\nGood Bye!";
				break;
		}
	}while(choice != 5);

	return 0;
}