/*
Ryan Lockman: 101430670
CSCI 2421:001 Fall 2013
hw3functions.cpp
Description: Global function definitions for Polynomial.
*/

// Headers
#include "hw3functions.h"

// Global Functions
