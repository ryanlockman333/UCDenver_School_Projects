/*
Ryan Lockman: 101430670
CSCI 2421:001 Fall 2013
hw3functions.h
Description: Global function prototypes for Polynomial.
*/

#ifndef hw3functions_H
#define hw3functions_H

#include "complex.h"

// Global Functions

#endif
